import React from 'react';
import Link from 'next/link';
import AppLogo from '@/components/ui/AppLogo';

export default function Footer() {
  return (
    <footer className="border-t border-white/5 bg-[#04080F]">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-16">
        {/* Two-row compact: Pattern 2 */}
        <div className="flex flex-col sm:flex-row justify-between gap-10 mb-10">
          {/* Brand */}
          <div className="flex items-center gap-2.5">
            <AppLogo size={32} />
            <span className="font-display font-bold text-white">ByteeVolvr</span>
          </div>

          {/* Link groups */}
          <div className="flex flex-wrap gap-10 text-sm">
            <div className="flex flex-col gap-3">
              <Link href="/services" className="text-brand-muted hover:text-white transition-colors font-medium">Services</Link>
              <Link href="/about" className="text-brand-muted hover:text-white transition-colors font-medium">About</Link>
            </div>
            <div className="flex flex-col gap-3">
              <Link href="/contact" className="text-brand-muted hover:text-white transition-colors font-medium">Contact</Link>
              <a href="https://shop.byteevolvr.com" target="_blank" rel="noopener noreferrer" className="text-accent hover:text-white transition-colors font-medium">Store</a>
            </div>
            <div className="flex flex-col gap-3">
              <Link href="/products" className="text-brand-muted hover:text-white transition-colors font-medium">Products</Link>
              <Link href="/admin" className="text-brand-muted hover:text-white transition-colors font-medium">Admin CMS</Link>
            </div>
          </div>
        </div>

        {/* Bottom row */}
        <div className="border-t border-white/5 pt-8 flex flex-col sm:flex-row justify-between items-center gap-4 text-xs text-brand-subtle font-mono">
          <span>© {new Date()?.getFullYear()} ByteeVolvr Enterprises. All rights reserved.</span>
          <div className="flex items-center gap-6">
            <a href="#" className="hover:text-brand-muted transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-brand-muted transition-colors">Terms of Service</a>
            <div className="flex items-center gap-3 ml-2">
              {/* LinkedIn */}
              <a href="#" aria-label="LinkedIn" className="text-brand-subtle hover:text-accent transition-colors">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M16 8a6 6 0 016 6v7h-4v-7a2 2 0 00-2-2 2 2 0 00-2 2v7h-4v-7a6 6 0 016-6zM2 9h4v12H2z"/><circle cx="4" cy="4" r="2"/></svg>
              </a>
              {/* Twitter/X */}
              <a href="#" aria-label="Twitter" className="text-brand-subtle hover:text-accent transition-colors">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.746l7.73-8.835L1.254 2.25H8.08l4.253 5.622zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
              </a>
              {/* WhatsApp */}
              <a href="#" aria-label="WhatsApp" className="text-brand-subtle hover:text-accent transition-colors">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}