'use client';
import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import AppLogo from '@/components/ui/AppLogo';

const navLinks = [
  { label: 'Services', href: '/services' },
  { label: 'About', href: '/about' },
  { label: 'Products', href: '/products' },
  { label: 'Contact', href: '/contact' },
];

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <>
      {/* Gradient blur top */}
      <div className="gradient-blur pointer-events-none z-40">
        <div /><div /><div /><div /><div /><div />
      </div>
      <nav
        className={`fixed z-50 top-0 inset-x-0 transition-all duration-500 ${
          scrolled
            ? 'bg-[#04080F]/90 backdrop-blur-xl border-b border-white/5'
            : 'bg-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          {/* Logo */}
          <Link href="/homepage" className="flex items-center gap-2.5 group">
            <AppLogo size={36} />
            <span className="font-display font-bold text-lg text-white tracking-tight group-hover:text-accent transition-colors">
              ByteeVolvr
            </span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-1 glass-panel rounded-full px-2 py-1.5">
            {navLinks?.map((link) => (
              <Link
                key={link?.label}
                href={link?.href}
                className="px-4 py-1.5 text-sm font-medium text-brand-muted hover:text-white rounded-full hover:bg-white/5 transition-all duration-200"
              >
                {link?.label}
              </Link>
            ))}
          </div>

          {/* CTA */}
          <div className="hidden md:flex items-center gap-3">
            <a
              href="https://shop.byteevolvr.com"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-primary px-5 py-2 rounded-lg text-sm font-semibold text-white flex items-center gap-2"
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 01-8 0"/>
              </svg>
              Visit Store
            </a>
          </div>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="md:hidden w-10 h-10 rounded-full glass-panel flex items-center justify-center"
            aria-label="Toggle menu"
          >
            <div className="flex flex-col gap-1.5 w-4">
              <span className={`h-[1.5px] bg-white rounded-full transition-all duration-300 ${menuOpen ? 'rotate-45 translate-y-[7px]' : ''}`} />
              <span className={`h-[1.5px] bg-white rounded-full transition-all duration-300 ${menuOpen ? 'opacity-0' : ''}`} />
              <span className={`h-[1.5px] bg-white rounded-full transition-all duration-300 ${menuOpen ? '-rotate-45 -translate-y-[7px]' : ''}`} />
            </div>
          </button>
        </div>

        {/* Mobile Menu */}
        {menuOpen && (
          <div className="md:hidden border-t border-white/5 bg-[#04080F]/95 backdrop-blur-xl px-6 py-6 flex flex-col gap-4">
            {navLinks?.map((link) => (
              <Link
                key={link?.label}
                href={link?.href}
                onClick={() => setMenuOpen(false)}
                className="text-sm font-medium text-brand-muted hover:text-white transition-colors py-2"
              >
                {link?.label}
              </Link>
            ))}
            <a
              href="https://shop.byteevolvr.com"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-primary px-5 py-3 rounded-lg text-sm font-semibold text-white text-center mt-2"
            >
              Visit Store →
            </a>
          </div>
        )}
      </nav>
    </>
  );
}