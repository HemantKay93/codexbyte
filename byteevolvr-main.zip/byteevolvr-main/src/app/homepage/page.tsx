import React from 'react';
import type { Metadata } from 'next';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import HeroSection from './components/HeroSection';
import ServicesSection from './components/ServicesSection';
import AboutSection from './components/AboutSection';
import TestimonialsSection from './components/TestimonialsSection';
import CTASection from './components/CTASection';

export const metadata: Metadata = {
  title: 'ByteeVolvr — IT Consulting & Technology Trading',
  description: 'ByteeVolvr Enterprises delivers end-to-end IT consulting, hardware trading, repair services, AMC contracts, and B2B supply for businesses and retail customers across India.',
};

export default function Homepage() {
  return (
    <main className="min-h-screen bg-[#04080F] overflow-x-hidden">
      <Header />
      <HeroSection />
      <ServicesSection />
      <AboutSection />
      <TestimonialsSection />
      <CTASection />
      <Footer />
    </main>
  );
}