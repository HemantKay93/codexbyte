'use client';
import React, { useEffect, useRef } from 'react';

export default function CTASection() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && e.target.classList.add('is-visible')),
      { threshold: 0.1 }
    );
    sectionRef?.current?.querySelectorAll('.observe-me')?.forEach((el) => observer?.observe(el));
    return () => observer?.disconnect();
  }, []);

  return (
    <section
      id="contact"
      ref={sectionRef}
      className="relative py-28 overflow-hidden"
      style={{ background: '#04080F' }}
    >
      {/* Central glow */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{ background: 'radial-gradient(ellipse 80% 50% at 50% 100%, rgba(26,79,214,0.12) 0%, transparent 70%)' }}
      />
      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">

        {/* Big CTA headline */}
        <div className="observe-me reveal-up text-center mb-20">
          <span className="text-xs font-mono text-accent uppercase tracking-widest mb-4 block">
            // Get Started
          </span>
          <h2
            className="font-display font-bold text-white tracking-tight leading-[0.85] mb-6"
            style={{ fontSize: 'clamp(2.5rem, 7vw, 6rem)' }}
          >
            Ready to upgrade
            <br />
            <span style={{ color: 'rgba(139,155,184,0.4)' }}>your IT infrastructure?</span>
          </h2>
          <p className="text-brand-muted font-body text-lg max-w-xl mx-auto leading-relaxed">
            Whether you need a one-time repair, an annual maintenance contract, or a complete
            IT strategy overhaul — we're ready when you are.
          </p>
        </div>

        {/* Dual panel split */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-px observe-me reveal-up" style={{ transitionDelay: '0.1s', background: 'rgba(255,255,255,0.05)', borderRadius: '20px', overflow: 'hidden' }}>

          {/* Panel 1: E-commerce redirect */}
          <div
            className="relative p-10 lg:p-14 flex flex-col justify-between group hover-shine"
            style={{
              background: 'linear-gradient(135deg, #0A1628, #070D1A)',
              minHeight: '360px',
              borderRight: '1px solid rgba(255,255,255,0.04)',
            }}
          >
            {/* Background pattern */}
            <div
              className="absolute inset-0 opacity-[0.04]"
              style={{
                backgroundImage: 'radial-gradient(rgba(96,165,250,1) 1px, transparent 1px)',
                backgroundSize: '28px 28px',
              }}
            />

            <div className="relative z-10">
              <div
                className="w-14 h-14 rounded-2xl flex items-center justify-center mb-6"
                style={{ background: 'rgba(26,79,214,0.2)', border: '1px solid rgba(96,165,250,0.25)' }}
              >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#60A5FA" strokeWidth="1.5">
                  <path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z" /><line x1="3" y1="6" x2="21" y2="6" /><path d="M16 10a4 4 0 01-8 0" />
                </svg>
              </div>
              <h3 className="font-display text-2xl font-bold text-white mb-3">Shop Our Online Store</h3>
              <p className="text-brand-muted text-sm leading-relaxed font-body mb-8">
                Browse 3,000+ genuine IT products — laptops, parts, peripherals, and mobile
                accessories. Pan-India delivery with easy returns.
              </p>
              <div className="flex flex-wrap gap-2 mb-8">
                {['3000+ Products', 'Genuine OEM', 'Fast Delivery', 'Easy Returns']?.map((t) => (
                  <span
                    key={t}
                    className="text-[10px] font-mono px-2.5 py-1 rounded-full"
                    style={{ background: 'rgba(26,79,214,0.12)', border: '1px solid rgba(96,165,250,0.2)', color: '#93C5FD' }}
                  >
                    {t}
                  </span>
                ))}
              </div>
            </div>
            <a
              href="https://shop.byteevolvr.com"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-primary relative z-10 inline-flex items-center gap-3 px-8 py-4 rounded-xl text-base font-semibold text-white font-display group-hover:gap-4 transition-all duration-300 w-fit"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z" /><line x1="3" y1="6" x2="21" y2="6" /><path d="M16 10a4 4 0 01-8 0" />
              </svg>
              Visit Our Store
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" className="group-hover:translate-x-1 transition-transform">
                <line x1="5" y1="12" x2="19" y2="12" /><polyline points="12 5 19 12 12 19" />
              </svg>
            </a>
          </div>

          {/* Panel 2: Contact form */}
          <div
            className="p-10 lg:p-14 flex flex-col"
            style={{ background: '#070D1A', minHeight: '360px' }}
          >
            <div
              className="w-14 h-14 rounded-2xl flex items-center justify-center mb-6"
              style={{ background: 'rgba(96,165,250,0.08)', border: '1px solid rgba(96,165,250,0.15)' }}
            >
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#60A5FA" strokeWidth="1.5">
                <path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z" />
              </svg>
            </div>
            <h3 className="font-display text-2xl font-bold text-white mb-3">Talk to Our Team</h3>
            <p className="text-brand-muted text-sm leading-relaxed font-body mb-6">
              For AMC quotes, B2B supply inquiries, or IT consulting engagements — drop us a message
              and we'll respond within 2 business hours.
            </p>

            {/* Contact form — UI only, no backend */}
            <form className="flex flex-col gap-4 flex-1" onSubmit={(e) => e?.preventDefault()}>
              {/* Backend connection point: Connect form submission to email/CRM API */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-mono text-brand-subtle mb-1.5 block uppercase tracking-wider">Name</label>
                  <input
                    type="text"
                    placeholder="Rajesh Mehta"
                    className="w-full px-4 py-3 rounded-lg text-sm text-white placeholder-brand-subtle font-body focus:outline-none focus:border-accent/50 transition-colors"
                    style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}
                  />
                </div>
                <div>
                  <label className="text-xs font-mono text-brand-subtle mb-1.5 block uppercase tracking-wider">Company</label>
                  <input
                    type="text"
                    placeholder="Your Company"
                    className="w-full px-4 py-3 rounded-lg text-sm text-white placeholder-brand-subtle font-body focus:outline-none focus:border-accent/50 transition-colors"
                    style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}
                  />
                </div>
              </div>
              <div>
                <label className="text-xs font-mono text-brand-subtle mb-1.5 block uppercase tracking-wider">Service Needed</label>
                <select
                  className="w-full px-4 py-3 rounded-lg text-sm font-body focus:outline-none transition-colors"
                  style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', color: '#8B9BB8' }}
                  defaultValue=""
                >
                  <option value="" disabled>Select a service...</option>
                  <option value="consulting" style={{ background: '#070D1A' }}>IT Consulting</option>
                  <option value="amc" style={{ background: '#070D1A' }}>AMC Contract</option>
                  <option value="repair" style={{ background: '#070D1A' }}>Repair & Maintenance</option>
                  <option value="b2b" style={{ background: '#070D1A' }}>B2B Supply</option>
                  <option value="parts" style={{ background: '#070D1A' }}>Parts & Accessories</option>
                  <option value="other" style={{ background: '#070D1A' }}>Other</option>
                </select>
              </div>
              <div>
                <label className="text-xs font-mono text-brand-subtle mb-1.5 block uppercase tracking-wider">Message</label>
                <textarea
                  placeholder="Briefly describe your requirement..."
                  rows={3}
                  className="w-full px-4 py-3 rounded-lg text-sm text-white placeholder-brand-subtle font-body focus:outline-none resize-none transition-colors"
                  style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}
                />
              </div>
              <button
                type="submit"
                className="btn-ghost px-6 py-3.5 rounded-lg text-sm font-semibold text-white font-display flex items-center gap-2 w-fit mt-auto"
              >
                Send Enquiry
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                  <line x1="22" y1="2" x2="11" y2="13" /><polygon points="22 2 15 22 11 13 2 9 22 2" />
                </svg>
              </button>
            </form>
          </div>
        </div>

        {/* Contact info bar */}
        <div
          className="observe-me reveal-up mt-8 grid grid-cols-1 sm:grid-cols-3 gap-px"
          style={{
            transitionDelay: '0.2s',
            background: 'rgba(255,255,255,0.04)',
            borderRadius: '14px',
            overflow: 'hidden',
          }}
        >
          {[
            {
              icon: (
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#60A5FA" strokeWidth="1.5">
                  <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 13.5 19.79 19.79 0 01.02 4.82 2 2 0 012 2.67h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.91 10a16 16 0 006.09 6.09l1.41-1.41a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 16.92z" />
                </svg>
              ),
              label: 'Call / WhatsApp',
              value: '+91 98765 43210',
            },
            {
              icon: (
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#60A5FA" strokeWidth="1.5">
                  <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" /><polyline points="22,6 12,13 2,6" />
                </svg>
              ),
              label: 'Email Us',
              value: 'hello@byteevolvr.com',
            },
            {
              icon: (
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#60A5FA" strokeWidth="1.5">
                  <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z" /><circle cx="12" cy="10" r="3" />
                </svg>
              ),
              label: 'Head Office',
              value: 'Mumbai, Maharashtra',
            },
          ]?.map((item) => (
            <div
              key={item?.label}
              className="flex items-center gap-4 px-6 py-5"
              style={{ background: '#070D1A' }}
            >
              <div
                className="w-9 h-9 rounded-lg flex items-center justify-center shrink-0"
                style={{ background: 'rgba(26,79,214,0.12)', border: '1px solid rgba(96,165,250,0.15)' }}
              >
                {item?.icon}
              </div>
              <div>
                <div className="text-[10px] font-mono text-brand-subtle uppercase tracking-wider">{item?.label}</div>
                <div className="text-white text-sm font-medium font-body">{item?.value}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}