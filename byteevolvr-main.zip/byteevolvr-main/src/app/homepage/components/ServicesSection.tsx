'use client';
import React, { useEffect, useRef } from 'react';

interface Service {
  id: string;
  icon: React.ReactNode;
  title: string;
  desc: string;
  tags: string[];
  accent: string;
  span?: string;
}

const services: Service[] = [
  {
    id: 'consulting',
    icon: (
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
        <rect x="2" y="3" width="20" height="14" rx="2" /><line x1="8" y1="21" x2="16" y2="21" /><line x1="12" y1="17" x2="12" y2="21" />
      </svg>
    ),
    title: 'IT Consulting',
    desc: 'End-to-end technology strategy, infrastructure planning, network architecture, and digital transformation roadmaps for growing businesses.',
    tags: ['Strategy', 'Network', 'Cloud', 'Security'],
    accent: '#3B7BF8',
    span: 'col-span-12 md:col-span-7',
  },
  {
    id: 'repair',
    icon: (
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
        <path d="M14.7 6.3a1 1 0 000 1.4l1.6 1.6a1 1 0 001.4 0l3.77-3.77a6 6 0 01-7.94 7.94l-6.91 6.91a2.12 2.12 0 01-3-3l6.91-6.91a6 6 0 017.94-7.94l-3.76 3.76z" />
      </svg>
    ),
    title: 'Repair & Maintenance',
    desc: 'Expert laptop, desktop, and mobile device repair with same-day turnaround for most issues. Certified technicians on-site and in-store.',
    tags: ['Laptops', 'Mobiles', 'Same-Day'],
    accent: '#60A5FA',
    span: 'col-span-12 md:col-span-5',
  },
  {
    id: 'amc',
    icon: (
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
      </svg>
    ),
    title: 'AMC Contracts',
    desc: 'Annual Maintenance Contracts with guaranteed SLAs, priority response, and proactive monitoring. Keep your IT infrastructure at peak health year-round.',
    tags: ['SLA Guaranteed', 'Proactive', 'Priority Support'],
    accent: '#1A4FD6',
    span: 'col-span-12 md:col-span-5',
  },
  {
    id: 'trading',
    icon: (
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
        <rect x="2" y="7" width="20" height="14" rx="2" /><path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16" />
      </svg>
    ),
    title: 'Parts & Accessories Trading',
    desc: 'Genuine OEM and compatible computer parts, laptop components, and mobile accessories sourced directly from verified distributors.',
    tags: ['OEM Parts', 'Accessories', 'Wholesale'],
    accent: '#93C5FD',
    span: 'col-span-12 md:col-span-7',
  },
  {
    id: 'b2b',
    icon: (
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
        <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M23 21v-2a4 4 0 00-3-3.87" /><path d="M16 3.13a4 4 0 010 7.75" />
      </svg>
    ),
    title: 'B2B Supply',
    desc: 'Bulk procurement and supply contracts for corporates, government offices, schools, and IT resellers. Volume pricing with dedicated account management.',
    tags: ['Corporate', 'Volume Pricing', 'Dedicated AM'],
    accent: '#3B7BF8',
    span: 'col-span-12 md:col-span-6',
  },
  {
    id: 'ecommerce',
    icon: (
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
        <path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z" /><line x1="3" y1="6" x2="21" y2="6" /><path d="M16 10a4 4 0 01-8 0" />
      </svg>
    ),
    title: 'E-Commerce Store',
    desc: 'Shop 3,000+ IT products online — from peripherals to server components. Fast delivery, genuine products, and hassle-free returns.',
    tags: ['3000+ Products', 'Fast Delivery', 'Genuine'],
    accent: '#60A5FA',
    span: 'col-span-12 md:col-span-6',
  },
];

export default function ServicesSection() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
          }
        });
      },
      { threshold: 0.1, rootMargin: '0px 0px -60px 0px' }
    );
    const section = sectionRef.current;
    if (section) {
      section.querySelectorAll('.observe-me').forEach((el) => observer.observe(el));
    }
    return () => observer.disconnect();
  }, []);

  return (
    <section id="services" ref={sectionRef} className="relative py-28 overflow-hidden" style={{ background: '#04080F' }}>
      {/* Ambient glow */}
      <div
        className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] pointer-events-none"
        style={{ background: 'radial-gradient(ellipse, rgba(26,79,214,0.08) 0%, transparent 70%)' }}
      />

      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="observe-me reveal-up flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
          <div>
            <span className="text-xs font-mono text-accent uppercase tracking-widest mb-3 block">
              // What We Do
            </span>
            <h2 className="font-display text-4xl lg:text-6xl font-bold text-white tracking-tight leading-[0.9]">
              <span className="block">Full-Stack</span>
              <span className="block" style={{ color: 'rgba(139,155,184,0.5)' }}>IT Services</span>
            </h2>
          </div>
          <p className="text-brand-muted font-mono text-sm max-w-xs text-right">
            // CONSULTING // REPAIR // SUPPLY // AMC
          </p>
        </div>

        {/* Bento Grid */}
        <div
          className="grid grid-cols-12 gap-px observe-me stagger-children"
          style={{ background: 'rgba(255,255,255,0.04)', borderRadius: '16px', overflow: 'hidden' }}
        >
          {services.map((svc) => (
            <div
              key={svc.id}
              className={`${svc.span} reveal-up hover-shine card-glow group cursor-default`}
              style={{
                background: '#04080F',
                padding: '2rem',
                borderRight: '1px solid rgba(255,255,255,0.04)',
                borderBottom: '1px solid rgba(255,255,255,0.04)',
                transition: 'background 0.4s ease, border-color 0.4s ease',
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLDivElement).style.background = '#070D1A';
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLDivElement).style.background = '#04080F';
              }}
            >
              {/* Icon */}
              <div
                className="w-12 h-12 rounded-xl flex items-center justify-center mb-5 transition-all duration-300 group-hover:scale-110"
                style={{
                  background: `${svc.accent}15`,
                  border: `1px solid ${svc.accent}30`,
                  color: svc.accent,
                }}
              >
                {svc.icon}
              </div>

              {/* Title */}
              <h3 className="font-display text-xl font-semibold text-white mb-3 group-hover:text-accent transition-colors">
                {svc.title}
              </h3>

              {/* Description */}
              <p className="text-brand-muted text-sm leading-relaxed mb-5 font-body">
                {svc.desc}
              </p>

              {/* Tags */}
              <div className="flex flex-wrap gap-2">
                {svc.tags.map((tag) => (
                  <span
                    key={tag}
                    className="text-[10px] font-mono px-2.5 py-1 rounded-full"
                    style={{
                      background: `${svc.accent}10`,
                      border: `1px solid ${svc.accent}25`,
                      color: svc.accent,
                    }}
                  >
                    {tag}
                  </span>
                ))}
              </div>

              {/* Hover arrow */}
              {svc.id === 'ecommerce' && (
                <a
                  href="https://shop.byteevolvr.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-5 inline-flex items-center gap-2 text-sm font-semibold text-accent pointer-events-auto"
                  style={{ borderBottom: '1px solid rgba(96,165,250,0.3)', paddingBottom: '2px' }}
                >
                  Visit Store
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                    <line x1="5" y1="12" x2="19" y2="12" /><polyline points="12 5 19 12 12 19" />
                  </svg>
                </a>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}