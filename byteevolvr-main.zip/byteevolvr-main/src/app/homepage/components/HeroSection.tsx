'use client';
import React, { useEffect, useRef } from 'react';

const CHARS_LINE1 = 'BYTEEVOLVR'?.split('');
const CHARS_LINE2 = 'ENTERPRISES'?.split('');

export default function HeroSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const textRef = useRef<HTMLDivElement>(null);
  const visualRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef?.current;
    if (!section) return;
    const timer = setTimeout(() => {
      section?.classList?.add('is-visible');
    }, 100);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      const scrolled = window.scrollY;
      if (scrolled > window.innerHeight) return;
      if (textRef?.current) {
        textRef.current.style.transform = `translate3d(0, ${scrolled * 0.18}px, 0)`;
        textRef.current.style.opacity = String(Math.max(0, 1 - scrolled / (window.innerHeight * 0.7)));
      }
      if (visualRef?.current) {
        visualRef.current.style.transform = `translate3d(0, ${scrolled * -0.08}px, 0)`;
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <section
      ref={sectionRef}
      id="hero"
      className="relative min-h-screen flex flex-col justify-center overflow-hidden"
      style={{ background: 'linear-gradient(180deg, #04080F 0%, #070D1A 60%, #04080F 100%)' }}
    >
      {/* ── BACKGROUND LAYERS ── */}
      {/* Dot grid */}
      <div
        className="absolute inset-0 z-0 pointer-events-none opacity-[0.18]"
        style={{
          backgroundImage: 'radial-gradient(rgba(96,165,250,0.6) 1px, transparent 1px)',
          backgroundSize: '44px 44px',
          maskImage: 'radial-gradient(ellipse at 50% 50%, black, transparent 75%)',
        }}
      />
      {/* Blob 1 */}
      <div
        className="absolute top-1/4 left-1/4 w-[500px] h-[500px] pointer-events-none z-0 animate-blob"
        style={{
          background: 'radial-gradient(circle, rgba(26,79,214,0.18) 0%, rgba(26,79,214,0.04) 60%, transparent 80%)',
          filter: 'blur(40px)',
        }}
      />
      {/* Blob 2 */}
      <div
        className="absolute bottom-1/3 right-1/4 w-[400px] h-[400px] pointer-events-none z-0"
        style={{
          background: 'radial-gradient(circle, rgba(96,165,250,0.12) 0%, rgba(96,165,250,0.03) 60%, transparent 80%)',
          filter: 'blur(50px)',
          animation: 'blob-morph 15s ease-in-out infinite 4s',
        }}
      />
      {/* Scan line */}
      <div
        className="absolute left-0 w-full pointer-events-none z-0 animate-scan"
        style={{
          height: '2px',
          background: 'linear-gradient(90deg, transparent 0%, rgba(96,165,250,0.15) 20%, rgba(96,165,250,0.4) 50%, rgba(96,165,250,0.15) 80%, transparent 100%)',
        }}
      />
      {/* SVG Beam lines */}
      <svg
        className="absolute inset-0 w-full h-full pointer-events-none z-0 opacity-30"
        preserveAspectRatio="xMidYMid slice"
        viewBox="0 0 1440 900"
        fill="none"
      >
        <defs>
          <linearGradient id="beam-blue" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#1A4FD6" stopOpacity="0" />
            <stop offset="50%" stopColor="#60A5FA" stopOpacity="0.8" />
            <stop offset="100%" stopColor="#1A4FD6" stopOpacity="0" />
          </linearGradient>
          <linearGradient id="beam-blue2" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#3B7BF8" stopOpacity="0" />
            <stop offset="50%" stopColor="#93C5FD" stopOpacity="0.6" />
            <stop offset="100%" stopColor="#3B7BF8" stopOpacity="0" />
          </linearGradient>
        </defs>
        <path
          d="M 200 700 C 400 700, 600 200, 720 200"
          stroke="rgba(26,79,214,0.08)"
          strokeWidth="2"
        />
        <path
          d="M 200 700 C 400 700, 600 200, 720 200"
          stroke="url(#beam-blue)"
          strokeWidth="3"
          className="animate-beam"
        />
        <path
          d="M 1240 700 C 1040 700, 840 200, 720 200"
          stroke="rgba(26,79,214,0.08)"
          strokeWidth="2"
        />
        <path
          d="M 1240 700 C 1040 700, 840 200, 720 200"
          stroke="url(#beam-blue2)"
          strokeWidth="3"
          className="animate-beam"
          style={{ animationDelay: '1.5s' }}
        />
      </svg>
      {/* ── CONTENT ── */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8 pt-28 pb-20 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-x-12 gap-y-16 items-center">

          {/* LEFT: Typography */}
          <div ref={textRef} className="lg:col-span-7 flex flex-col gap-6">

            {/* Status badge */}
            <div className="is-visible">
              <div
                className="inline-flex items-center gap-2.5 px-4 py-2 rounded-full glass-panel border border-accent/20 reveal-up is-visible"
                style={{ transitionDelay: '0.1s' }}
              >
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-accent opacity-75" />
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-accent" />
                </span>
                <span className="text-xs font-mono text-accent tracking-widest uppercase">
                  IT Consulting & Technology Trading
                </span>
              </div>
            </div>

            {/* Main headline */}
            <h1
              className="font-display font-bold leading-[0.85] tracking-tighter select-none"
              style={{ fontSize: 'clamp(3.5rem, 9vw, 8rem)' }}
            >
              <div
                className="is-visible"
                aria-label="BYTEEVOLVR"
              >
                {CHARS_LINE1?.map((ch, i) => (
                  <span
                    key={i}
                    className="reveal-char text-light-scan"
                    style={{ transitionDelay: `${0.2 + i * 0.035}s` }}
                  >
                    {ch}
                  </span>
                ))}
              </div>
              <div
                className="is-visible pl-8 lg:pl-20"
                aria-label="ENTERPRISES"
              >
                {CHARS_LINE2?.map((ch, i) => (
                  <span
                    key={i}
                    className="reveal-char"
                    style={{
                      transitionDelay: `${0.5 + i * 0.03}s`,
                      color: 'rgba(139,155,184,0.5)',
                    }}
                  >
                    {ch}
                  </span>
                ))}
              </div>
            </h1>

            {/* Subheadline */}
            <p
              className="reveal-up is-visible text-brand-muted font-body text-lg leading-relaxed max-w-xl"
              style={{ transitionDelay: '0.8s' }}
            >
              From IT strategy to spare parts delivery — ByteeVolvr is your end-to-end
              technology partner. We consult, supply, repair, and maintain so your business
              never skips a beat.
            </p>

            {/* CTAs */}
            <div
              className="reveal-up is-visible flex flex-wrap gap-4 mt-2"
              style={{ transitionDelay: '1s' }}
            >
              <a
                href="#services"
                onClick={(e) => { e?.preventDefault(); document.querySelector('#services')?.scrollIntoView({ behavior: 'smooth' }); }}
                className="btn-primary px-7 py-3.5 rounded-lg text-sm font-semibold text-white flex items-center gap-2 font-display"
              >
                Explore Services
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                  <line x1="5" y1="12" x2="19" y2="12" /><polyline points="12 5 19 12 12 19" />
                </svg>
              </a>
              <a
                href="https://shop.byteevolvr.com"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-ghost px-7 py-3.5 rounded-lg text-sm font-semibold text-white flex items-center gap-2 font-display"
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z" /><line x1="3" y1="6" x2="21" y2="6" /><path d="M16 10a4 4 0 01-8 0" />
                </svg>
                Shop Online
              </a>
            </div>

            {/* Quick stats */}
            <div
              className="reveal-up is-visible grid grid-cols-3 gap-6 mt-4 pt-6 border-t border-white/5"
              style={{ transitionDelay: '1.15s' }}
            >
              {[
                { val: '10+', label: 'Years in IT' },
                { val: '500+', label: 'B2B Clients' },
                { val: '24/7', label: 'AMC Support' },
              ]?.map((s) => (
                <div key={s?.label} className="flex flex-col gap-1">
                  <span className="font-display text-2xl font-bold text-white">{s?.val}</span>
                  <span className="text-xs font-mono text-brand-subtle uppercase tracking-wider">{s?.label}</span>
                </div>
              ))}
            </div>
          </div>

          {/* RIGHT: Visual panel */}
          <div
            ref={visualRef}
            className="lg:col-span-5 hidden lg:flex items-center justify-center relative pointer-events-none select-none"
          >
            <div
              className="reveal-blur is-visible relative w-full aspect-[3/4] max-w-[360px]"
              style={{ transitionDelay: '0.4s' }}
            >
              {/* Outer glow ring */}
              <div
                className="absolute inset-0 rounded-2xl animate-float"
                style={{
                  background: 'linear-gradient(135deg, rgba(26,79,214,0.15) 0%, rgba(96,165,250,0.05) 100%)',
                  border: '1px solid rgba(96,165,250,0.12)',
                  boxShadow: '0 0 60px rgba(26,79,214,0.15), inset 0 0 40px rgba(26,79,214,0.05)',
                }}
              />

              {/* Inner UI mockup */}
              <div
                className="absolute inset-3 rounded-xl overflow-hidden flex flex-col"
                style={{ background: '#070D1A', border: '1px solid rgba(255,255,255,0.05)' }}
              >
                {/* Top bar */}
                <div className="h-10 flex items-center px-4 gap-2 border-b border-white/5" style={{ background: 'rgba(255,255,255,0.02)' }}>
                  <div className="w-2.5 h-2.5 rounded-full bg-white/10" />
                  <div className="w-2.5 h-2.5 rounded-full bg-white/10" />
                  <div className="flex-1 mx-2 h-1.5 rounded-full bg-white/5" />
                  <span className="text-[9px] font-mono text-accent/70">LIVE</span>
                  <span className="w-1.5 h-1.5 rounded-full bg-accent animate-pulse-glow" />
                </div>

                {/* Content area */}
                <div className="flex-1 p-4 flex flex-col gap-3 relative">
                  {/* Status row */}
                  <div className="flex gap-2">
                    {['IT Consulting', 'AMC Active', 'B2B']?.map((tag) => (
                      <span
                        key={tag}
                        className="text-[8px] font-mono px-2 py-1 rounded"
                        style={{ background: 'rgba(26,79,214,0.15)', border: '1px solid rgba(96,165,250,0.2)', color: '#93C5FD' }}
                      >
                        {tag}
                      </span>
                    ))}
                  </div>

                  {/* Chart bars */}
                  <div className="flex-1 flex flex-col justify-end gap-1">
                    {[65, 80, 45, 90, 70, 85, 55]?.map((h, i) => (
                      <div key={i} className="flex items-center gap-2">
                        <span className="text-[7px] font-mono text-brand-subtle w-8">
                          {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']?.[i]}
                        </span>
                        <div className="flex-1 h-3 rounded-sm overflow-hidden" style={{ background: 'rgba(255,255,255,0.04)' }}>
                          <div
                            className="h-full rounded-sm"
                            style={{
                              width: `${h}%`,
                              background: `linear-gradient(90deg, #1A4FD6, #60A5FA)`,
                              opacity: 0.7 + i * 0.04,
                            }}
                          />
                        </div>
                        <span className="text-[7px] font-mono text-brand-muted">{h}%</span>
                      </div>
                    ))}
                  </div>

                  {/* Bottom metric */}
                  <div
                    className="rounded-lg p-3 flex justify-between items-center"
                    style={{ background: 'rgba(26,79,214,0.1)', border: '1px solid rgba(96,165,250,0.15)' }}
                  >
                    <div>
                      <div className="text-[8px] font-mono text-brand-subtle uppercase">Uptime SLA</div>
                      <div className="text-lg font-display font-bold text-white">99.8%</div>
                    </div>
                    <div className="text-[8px] font-mono text-accent bg-accent/10 px-2 py-1 rounded">+2.1%</div>
                  </div>

                  {/* Scan overlay */}
                  <div
                    className="absolute left-0 w-full pointer-events-none animate-scan"
                    style={{
                      height: '1px',
                      background: 'linear-gradient(90deg, transparent, rgba(96,165,250,0.3), transparent)',
                    }}
                  />
                </div>
              </div>

              {/* Floating chip 1 */}
              <div
                className="absolute -top-4 -right-4 glass-panel-blue rounded-xl px-3 py-2 flex items-center gap-2 animate-float"
                style={{ animationDelay: '0.5s' }}
              >
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#60A5FA" strokeWidth="2">
                  <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
                </svg>
                <span className="text-[10px] font-mono text-accent">Repair Completed</span>
              </div>

              {/* Floating chip 2 */}
              <div
                className="absolute -bottom-4 -left-4 glass-panel-blue rounded-xl px-3 py-2 flex items-center gap-2 animate-float"
                style={{ animationDelay: '1.2s' }}
              >
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#60A5FA" strokeWidth="2">
                  <path d="M20 7H4a2 2 0 00-2 2v6a2 2 0 002 2h16a2 2 0 002-2V9a2 2 0 00-2-2z" /><circle cx="12" cy="12" r="2" />
                </svg>
                <span className="text-[10px] font-mono text-accent">AMC Renewed</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Bottom fade */}
      <div
        className="absolute bottom-0 left-0 w-full h-32 pointer-events-none z-0"
        style={{ background: 'linear-gradient(to bottom, transparent, #04080F)' }}
      />
      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-2 animate-float">
        <span className="text-[10px] font-mono text-brand-subtle uppercase tracking-widest">Scroll</span>
        <svg width="16" height="20" viewBox="0 0 16 20" fill="none">
          <rect x="1" y="1" width="14" height="18" rx="7" stroke="rgba(255,255,255,0.15)" strokeWidth="1.5" />
          <rect x="6" y="4" width="4" height="6" rx="2" fill="rgba(96,165,250,0.5)" />
        </svg>
      </div>
    </section>
  );
}