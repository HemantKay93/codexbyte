'use client';
import React, { useEffect, useRef } from 'react';
import AppImage from '@/components/ui/AppImage';

const stats = [
{ val: '10+', label: 'Years Experience', sub: 'In IT consulting & trading' },
{ val: '500+', label: 'Business Clients', sub: 'Across India' },
{ val: '3000+', label: 'Products Listed', sub: 'In our online store' },
{ val: '99.8%', label: 'AMC SLA Uptime', sub: 'Guaranteed response' }];


const milestones = [
{ year: '2013', event: 'Founded in Mumbai as an IT repair & parts shop' },
{ year: '2016', event: 'Launched B2B supply division for corporate clients' },
{ year: '2019', event: 'Expanded to full IT consulting and AMC services' },
{ year: '2022', event: 'Launched e-commerce store with pan-India delivery' },
{ year: '2025', event: 'Serving 500+ businesses with end-to-end IT solutions' }];


export default function AboutSection() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && e.target.classList.add('is-visible')),
      { threshold: 0.1, rootMargin: '0px 0px -50px 0px' }
    );
    sectionRef?.current?.querySelectorAll('.observe-me')?.forEach((el) => observer?.observe(el));
    return () => observer?.disconnect();
  }, []);

  return (
    <section
      id="about"
      ref={sectionRef}
      className="relative py-28 overflow-hidden"
      style={{ background: 'linear-gradient(180deg, #04080F 0%, #070D1A 50%, #04080F 100%)' }}>
      
      {/* Background grid */}
      <div
        className="absolute inset-0 opacity-[0.03] pointer-events-none"
        style={{
          backgroundImage: 'linear-gradient(rgba(96,165,250,1) 1px, transparent 1px), linear-gradient(90deg, rgba(96,165,250,1) 1px, transparent 1px)',
          backgroundSize: '60px 60px'
        }} />
      
      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">

        {/* Section label */}
        <div className="observe-me reveal-up mb-16">
          <span className="text-xs font-mono text-accent uppercase tracking-widest">// About Us</span>
        </div>

        {/* Main grid: 60/40 split */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-start">

          {/* LEFT: Story */}
          <div className="lg:col-span-7 flex flex-col gap-10">
            <div className="observe-me reveal-up">
              <h2 className="font-display text-4xl lg:text-5xl font-bold text-white tracking-tight leading-tight mb-6">
                We don't just fix computers —
                <span style={{ color: 'rgba(139,155,184,0.45)' }}> we architect the technology backbone of your business.</span>
              </h2>
              <p className="text-brand-muted text-base leading-relaxed font-body">
                ByteeVolvr Enterprises started as a small computer repair shop in Mumbai in 2013.
                Over a decade, we've grown into a full-spectrum IT company trusted by 500+ businesses
                across India — from neighborhood retailers to large corporates.
              </p>
            </div>

            <div className="observe-me reveal-up" style={{ transitionDelay: '0.15s' }}>
              <p className="text-brand-muted text-base leading-relaxed font-body">
                Our strength is versatility. We handle IT consulting for Fortune 500 vendors,
                supply genuine computer parts to resellers, provide AMC support with guaranteed
                SLAs, and run a growing e-commerce platform with 3,000+ technology products.
              </p>
            </div>

            {/* Photo */}
            <div
              className="observe-me reveal-blur rounded-2xl overflow-hidden relative"
              style={{ transitionDelay: '0.2s', border: '1px solid rgba(96,165,250,0.1)' }}>
              
              <AppImage
                src="https://img.rocket.new/generatedImages/rocket_gen_img_14598519e-1768103454712.png"
                alt="ByteeVolvr technician working on computer hardware circuit board repair"
                width={900}
                height={400}
                className="w-full object-cover"
                style={{ height: '260px' }} />
              
              <div
                className="absolute inset-0"
                style={{ background: 'linear-gradient(to top, rgba(4,8,15,0.7) 0%, transparent 60%)' }} />
              
              <div className="absolute bottom-4 left-5">
                <span className="text-xs font-mono text-accent/80">BYTEEVOLVR // MUMBAI HQ</span>
              </div>
            </div>

            {/* Milestones — asymmetric horizontal layout */}
            <div className="observe-me reveal-up" style={{ transitionDelay: '0.25s' }}>
              <h3 className="text-xs font-mono text-brand-subtle uppercase tracking-widest mb-6">Our Journey</h3>
              <div className="relative">
                {/* Connector line */}
                <div
                  className="absolute left-0 top-3 w-full h-px"
                  style={{ background: 'linear-gradient(90deg, rgba(26,79,214,0.5), rgba(96,165,250,0.2), transparent)' }} />
                
                <div className="flex flex-col gap-0">
                  {milestones?.map((m, i) =>
                  <div
                    key={m?.year}
                    className="flex items-start gap-5 py-4 border-b border-white/5 group hover:border-accent/20 transition-colors">
                    
                      <span
                      className="font-mono text-sm font-semibold shrink-0 w-12"
                      style={{ color: i === milestones?.length - 1 ? '#60A5FA' : 'rgba(139,155,184,0.5)' }}>
                      
                        {m?.year}
                      </span>
                      <span className="text-sm text-brand-muted group-hover:text-white transition-colors font-body leading-relaxed">
                        {m?.event}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* RIGHT: Stats panel */}
          <div className="lg:col-span-5 flex flex-col gap-4">
            {stats?.map((s, i) =>
            <div
              key={s?.label}
              className="observe-me reveal-up glass-panel card-glow rounded-2xl p-6 hover-shine group"
              style={{ transitionDelay: `${0.1 + i * 0.1}s` }}>
              
                <div
                className="text-4xl font-display font-bold mb-1 transition-all duration-300"
                style={{
                  background: 'linear-gradient(135deg, #ffffff, #60A5FA)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                  backgroundClip: 'text'
                }}>
                
                  {s?.val}
                </div>
                <div className="text-white font-display font-semibold text-base mb-0.5">{s?.label}</div>
                <div className="text-brand-subtle text-xs font-mono">{s?.sub}</div>
              </div>
            )}

            {/* Certifications */}
            <div
              className="observe-me reveal-up glass-panel-blue rounded-2xl p-6 mt-2"
              style={{ transitionDelay: '0.5s' }}>
              
              <h4 className="text-xs font-mono text-accent uppercase tracking-widest mb-4">Certifications & Partners</h4>
              <div className="flex flex-wrap gap-2">
                {['Microsoft Partner', 'HP Authorized', 'Dell Certified', 'Lenovo Reseller', 'GST Registered']?.map((cert) =>
                <span
                  key={cert}
                  className="text-[11px] font-mono px-3 py-1.5 rounded-full"
                  style={{ background: 'rgba(26,79,214,0.12)', border: '1px solid rgba(96,165,250,0.2)', color: '#93C5FD' }}>
                  
                    {cert}
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>);

}