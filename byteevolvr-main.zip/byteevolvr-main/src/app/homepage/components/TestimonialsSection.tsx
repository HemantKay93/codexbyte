'use client';
import React, { useEffect, useRef, useState } from 'react';
import AppImage from '@/components/ui/AppImage';

interface Testimonial {
  quote: string;
  name: string;
  title: string;
  company: string;
  avatar: string;
  rating: number;
}

const testimonials: Testimonial[] = [
{
  quote: "ByteeVolvr handles our entire office IT infrastructure. From network setup to 24/7 AMC support — their response time is unmatched. We've reduced downtime by 80% since signing with them.",
  name: 'Rajesh Mehta',
  title: 'Operations Director',
  company: 'Mehta Textiles Pvt. Ltd.',
  avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_198aabfbe-1767265264777.png",
  rating: 5
},
{
  quote: "We bulk-source all our laptop parts through ByteeVolvr's B2B supply channel. Pricing is competitive, quality is genuine, and delivery is always on time. Best IT supplier in the region.",
  name: 'Priya Nair',
  title: 'Procurement Manager',
  company: 'TechZone Retail Chain',
  avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_146e62e94-1764678764092.png",
  rating: 5
},
{
  quote: "Their IT consulting team mapped out our entire digital transformation. Clear roadmap, realistic budget, and they stayed with us through every step. Highly recommend for any SMB.",
  name: 'Amit Sharma',
  title: 'CEO',
  company: 'Sharma & Co. Exports',
  avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_1c554fc24-1772245883262.png",
  rating: 5
},
{
  quote: "Got my MacBook screen repaired same day! Genuine parts, fair pricing, and the technician explained everything clearly. ByteeVolvr is now my go-to for all device repairs.",
  name: 'Neha Kulkarni',
  title: 'Freelance Designer',
  company: 'Independent',
  avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_1606753ca-1769507101643.png",
  rating: 5
},
{
  quote: "The AMC contract has been a game-changer for our school's computer lab. Regular maintenance, instant support, and zero disruption to classes. Worth every rupee.",
  name: 'Suresh Patil',
  title: 'Principal',
  company: 'Sunrise International School',
  avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_1cb44530f-1773564863761.png",
  rating: 5
}];


function StarRating({ count }: {count: number;}) {
  return (
    <div className="flex gap-0.5">
      {Array.from({ length: count }).map((_, i) =>
      <svg key={i} width="12" height="12" viewBox="0 0 24 24" fill="#60A5FA">
          <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
        </svg>
      )}
    </div>);

}

export default function TestimonialsSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);
  const [activeIdx, setActiveIdx] = useState(0);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && e.target.classList.add('is-visible')),
      { threshold: 0.1 }
    );
    sectionRef.current?.querySelectorAll('.observe-me').forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  const scrollTo = (idx: number) => {
    setActiveIdx(idx);
    const track = trackRef.current;
    if (!track) return;
    const card = track.children[idx] as HTMLElement;
    if (card) {
      track.scrollTo({ left: card.offsetLeft - 24, behavior: 'smooth' });
    }
  };

  return (
    <section
      ref={sectionRef}
      className="relative py-28 overflow-hidden"
      style={{ background: '#070D1A' }}>
      
      {/* Ambient */}
      <div
        className="absolute bottom-0 right-0 w-[600px] h-[400px] pointer-events-none"
        style={{ background: 'radial-gradient(ellipse, rgba(26,79,214,0.07) 0%, transparent 70%)' }} />
      

      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="observe-me reveal-up flex flex-col md:flex-row justify-between items-end mb-14 gap-6">
          <div>
            <span className="text-xs font-mono text-accent uppercase tracking-widest mb-3 block">
              // Client Feedback
            </span>
            <h2 className="font-display text-4xl lg:text-5xl font-bold text-white tracking-tight leading-[0.9]">
              Trusted by
              <span style={{ color: 'rgba(139,155,184,0.45)' }}> businesses</span>
              <br />across India
            </h2>
          </div>
          {/* Dot nav */}
          <div className="flex items-center gap-2">
            {testimonials.map((_, i) =>
            <button
              key={i}
              onClick={() => scrollTo(i)}
              className="transition-all duration-300"
              style={{
                width: activeIdx === i ? '24px' : '8px',
                height: '8px',
                borderRadius: '4px',
                background: activeIdx === i ? '#1A4FD6' : 'rgba(255,255,255,0.15)'
              }}
              aria-label={`Go to testimonial ${i + 1}`} />

            )}
          </div>
        </div>

        {/* Scroll track */}
        <div
          ref={trackRef}
          className="testimonial-track observe-me reveal-up pb-4"
          style={{ transitionDelay: '0.1s' }}>
          
          {testimonials.map((t, i) =>
          <div
            key={t.name}
            className="glass-panel card-glow hover-shine rounded-2xl p-8 flex flex-col justify-between cursor-default group"
            style={{ width: '380px', minHeight: '260px', transition: 'all 0.4s ease' }}
            onMouseEnter={(e) => {
              setActiveIdx(i);
              (e.currentTarget as HTMLDivElement).style.transform = 'scale(1.02)';
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLDivElement).style.transform = 'scale(1)';
            }}>
            
              <div>
                <StarRating count={t.rating} />
                <p className="text-brand-fg text-sm leading-relaxed mt-4 font-body">
                  &ldquo;{t.quote}&rdquo;
                </p>
              </div>
              <div className="flex items-center gap-4 mt-6 pt-6 border-t border-white/5">
                <div className="w-10 h-10 rounded-full overflow-hidden ring-2 ring-accent/20 shrink-0">
                  <AppImage
                  src={t.avatar}
                  alt={`${t.name} - ${t.title} at ${t.company}`}
                  width={40}
                  height={40}
                  className="w-full h-full object-cover" />
                
                </div>
                <div>
                  <div className="text-white text-sm font-semibold font-display">{t.name}</div>
                  <div className="text-brand-subtle text-xs font-mono">{t.title}, {t.company}</div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>);

}