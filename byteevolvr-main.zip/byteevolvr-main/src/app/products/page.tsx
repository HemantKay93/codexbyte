'use client';
import React, { useState, useEffect, useCallback } from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { createClient } from '@/lib/supabase/client';
import AppImage from '@/components/ui/AppImage';

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  original_price: number | null;
  image_url: string;
  category: string;
  brand: string;
  sku: string;
  stock_quantity: number;
  tags: string[];
  status: string;
  featured: boolean;
  sort_order: number;
}

const CATEGORIES = ['All', 'Laptops', 'Monitors', 'Peripherals', 'Printers', 'Components', 'Storage', 'Networking'];

export default function ProductsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'featured' | 'price_asc' | 'price_desc' | 'newest'>('featured');

  const fetchProducts = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const supabase = createClient();
      let query = supabase
        .from('products')
        .select('*')
        .eq('status', 'active');

      if (selectedCategory !== 'All') {
        query = query.eq('category', selectedCategory);
      }

      if (searchQuery.trim()) {
        query = query.ilike('name', `%${searchQuery.trim()}%`);
      }

      if (sortBy === 'featured') {
        query = query.order('featured', { ascending: false }).order('sort_order', { ascending: true });
      } else if (sortBy === 'price_asc') {
        query = query.order('price', { ascending: true });
      } else if (sortBy === 'price_desc') {
        query = query.order('price', { ascending: false });
      } else {
        query = query.order('created_at', { ascending: false });
      }

      const { data, error: dbError } = await query;
      if (dbError) {
        setError('Failed to load products.');
      } else {
        setProducts(data || []);
      }
    } catch {
      setError('An unexpected error occurred.');
    } finally {
      setLoading(false);
    }
  }, [selectedCategory, searchQuery, sortBy]);

  useEffect(() => {
    fetchProducts();
  }, [fetchProducts]);

  const formatPrice = (price: number) =>
    new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(price);

  const getDiscount = (price: number, original: number | null) => {
    if (!original || original <= price) return null;
    return Math.round(((original - price) / original) * 100);
  };

  return (
    <main className="min-h-screen bg-[#04080F] overflow-x-hidden">
      <Header />

      {/* Hero */}
      <section className="relative pt-40 pb-16 overflow-hidden">
        <div
          className="absolute top-0 left-1/2 -translate-x-1/2 w-[900px] h-[500px] pointer-events-none"
          style={{ background: 'radial-gradient(ellipse, rgba(26,79,214,0.1) 0%, transparent 70%)' }}
        />
        <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
          <span className="text-xs font-mono text-accent uppercase tracking-widest mb-4 block">// E-Commerce</span>
          <h1 className="font-display text-5xl lg:text-7xl font-bold text-white tracking-tight leading-[0.9] mb-6">
            <span className="block">Products</span>
            <span className="block" style={{ color: 'rgba(139,155,184,0.5)' }}>& Accessories</span>
          </h1>
          <p className="text-brand-muted text-lg max-w-2xl font-body leading-relaxed">
            Genuine IT hardware, peripherals, and components sourced directly from authorized distributors. Fast delivery across India.
          </p>
        </div>
      </section>

      {/* Filters */}
      <section className="sticky top-[72px] z-30 border-b border-white/5"
        style={{ background: 'rgba(4,8,15,0.95)', backdropFilter: 'blur(20px)' }}>
        <div className="max-w-7xl mx-auto px-6 lg:px-8 py-4">
          <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
            {/* Search */}
            <div className="relative flex-1 max-w-sm">
              <svg className="absolute left-3 top-1/2 -translate-y-1/2 text-brand-subtle" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" />
              </svg>
              <input
                type="text"
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2 rounded-lg text-sm font-body text-white placeholder-brand-subtle outline-none"
                style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}
              />
            </div>

            {/* Sort */}
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
              className="px-4 py-2 rounded-lg text-sm font-body text-white outline-none appearance-none"
              style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}
            >
              <option value="featured" style={{ background: '#04080F' }}>Featured First</option>
              <option value="price_asc" style={{ background: '#04080F' }}>Price: Low to High</option>
              <option value="price_desc" style={{ background: '#04080F' }}>Price: High to Low</option>
              <option value="newest" style={{ background: '#04080F' }}>Newest First</option>
            </select>
          </div>

          {/* Category Pills */}
          <div className="flex gap-2 mt-3 overflow-x-auto pb-1 scrollbar-hide">
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className="shrink-0 px-4 py-1.5 rounded-full text-xs font-mono transition-all duration-200"
                style={{
                  background: selectedCategory === cat ? 'rgba(26,79,214,0.3)' : 'rgba(255,255,255,0.04)',
                  border: selectedCategory === cat ? '1px solid rgba(96,165,250,0.4)' : '1px solid rgba(255,255,255,0.08)',
                  color: selectedCategory === cat ? '#60A5FA' : '#8B9BB8',
                }}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Products Grid */}
      <section className="py-12 pb-32">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className="glass-panel rounded-2xl overflow-hidden animate-pulse">
                  <div className="h-48 bg-white/5" />
                  <div className="p-5">
                    <div className="h-4 bg-white/5 rounded mb-2 w-3/4" />
                    <div className="h-3 bg-white/5 rounded mb-4 w-1/2" />
                    <div className="h-6 bg-white/5 rounded w-1/3" />
                  </div>
                </div>
              ))}
            </div>
          ) : error ? (
            <div className="glass-panel rounded-2xl p-8 text-center">
              <p className="text-red-400 font-mono text-sm mb-4">{error}</p>
              <button
                onClick={fetchProducts}
                className="text-accent text-sm font-mono hover:text-white transition-colors"
              >
                Try again →
              </button>
            </div>
          ) : products.length === 0 ? (
            <div className="text-center py-20">
              <p className="text-brand-muted font-mono text-sm">No products found matching your criteria.</p>
              <button
                onClick={() => { setSelectedCategory('All'); setSearchQuery(''); }}
                className="mt-4 text-accent text-sm font-mono hover:text-white transition-colors"
              >
                Clear filters →
              </button>
            </div>
          ) : (
            <>
              <p className="text-brand-subtle font-mono text-xs mb-6">{products.length} product{products.length !== 1 ? 's' : ''} found</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {products.map((product) => {
                  const discount = getDiscount(product.price, product.original_price);
                  return (
                    <div
                      key={product.id}
                      className="glass-panel rounded-2xl overflow-hidden group hover-shine transition-all duration-300"
                      style={{ border: '1px solid rgba(255,255,255,0.06)' }}
                      onMouseEnter={(e) => { (e.currentTarget as HTMLDivElement).style.borderColor = 'rgba(96,165,250,0.2)'; }}
                      onMouseLeave={(e) => { (e.currentTarget as HTMLDivElement).style.borderColor = 'rgba(255,255,255,0.06)'; }}
                    >
                      {/* Image */}
                      <div className="relative h-48 overflow-hidden bg-white/3">
                        {product.image_url ? (
                          <AppImage
                            src={product.image_url}
                            alt={`${product.name} - ${product.brand} ${product.category} product image`}
                            width={400}
                            height={300}
                            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="rgba(139,155,184,0.3)" strokeWidth="1">
                              <rect x="3" y="3" width="18" height="18" rx="2" /><circle cx="8.5" cy="8.5" r="1.5" /><polyline points="21 15 16 10 5 21" />
                            </svg>
                          </div>
                        )}
                        {product.featured && (
                          <span
                            className="absolute top-3 left-3 text-[10px] font-mono px-2 py-1 rounded-full"
                            style={{ background: 'rgba(26,79,214,0.8)', border: '1px solid rgba(96,165,250,0.4)', color: '#93C5FD' }}
                          >
                            Featured
                          </span>
                        )}
                        {discount && (
                          <span
                            className="absolute top-3 right-3 text-[10px] font-mono px-2 py-1 rounded-full"
                            style={{ background: 'rgba(16,185,129,0.2)', border: '1px solid rgba(16,185,129,0.4)', color: '#34D399' }}
                          >
                            -{discount}%
                          </span>
                        )}
                      </div>

                      {/* Info */}
                      <div className="p-5">
                        <p className="text-[10px] font-mono text-brand-subtle uppercase tracking-widest mb-1">{product.brand} · {product.category}</p>
                        <h3 className="font-display text-sm font-semibold text-white mb-2 leading-snug line-clamp-2 group-hover:text-accent transition-colors">
                          {product.name}
                        </h3>
                        <p className="text-brand-muted text-xs font-body leading-relaxed mb-4 line-clamp-2">
                          {product.description}
                        </p>

                        {/* Tags */}
                        <div className="flex flex-wrap gap-1 mb-4">
                          {product.tags?.slice(0, 2).map((tag) => (
                            <span
                              key={tag}
                              className="text-[9px] font-mono px-2 py-0.5 rounded-full"
                              style={{ background: 'rgba(26,79,214,0.1)', border: '1px solid rgba(96,165,250,0.15)', color: '#93C5FD' }}
                            >
                              {tag}
                            </span>
                          ))}
                        </div>

                        {/* Price */}
                        <div className="flex items-end justify-between">
                          <div>
                            <p
                              className="font-display text-lg font-bold"
                              style={{
                                background: 'linear-gradient(135deg, #ffffff, #60A5FA)',
                                WebkitBackgroundClip: 'text',
                                WebkitTextFillColor: 'transparent',
                                backgroundClip: 'text',
                              }}
                            >
                              {formatPrice(product.price)}
                            </p>
                            {product.original_price && product.original_price > product.price && (
                              <p className="text-brand-subtle text-xs font-mono line-through">
                                {formatPrice(product.original_price)}
                              </p>
                            )}
                          </div>
                          <span
                            className="text-[10px] font-mono px-2 py-1 rounded-full"
                            style={{
                              background: product.stock_quantity > 0 ? 'rgba(16,185,129,0.1)' : 'rgba(239,68,68,0.1)',
                              border: product.stock_quantity > 0 ? '1px solid rgba(16,185,129,0.3)' : '1px solid rgba(239,68,68,0.3)',
                              color: product.stock_quantity > 0 ? '#34D399' : '#F87171',
                            }}
                          >
                            {product.stock_quantity > 0 ? 'In Stock' : 'Out of Stock'}
                          </span>
                        </div>

                        <a
                          href="https://shop.byteevolvr.com"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="mt-4 w-full btn-primary flex items-center justify-center gap-2 py-2.5 rounded-xl text-xs font-semibold text-white transition-opacity"
                        >
                          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                            <path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z" /><line x1="3" y1="6" x2="21" y2="6" /><path d="M16 10a4 4 0 01-8 0" />
                          </svg>
                          Buy Now
                        </a>
                      </div>
                    </div>
                  );
                })}
              </div>
            </>
          )}
        </div>
      </section>

      <Footer />
    </main>
  );
}
