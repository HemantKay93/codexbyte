import React from 'react';
import type { Metadata } from 'next';
import { createClient } from '@/lib/supabase/server';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import AppImage from '@/components/ui/AppImage';

export const metadata: Metadata = {
  title: 'About Us — ByteeVolvr Enterprises',
  description: 'Learn about ByteeVolvr Enterprises — a decade of IT excellence, 500+ business clients, and full-spectrum technology services across India.'
};

interface Stat {
  val: string;
  label: string;
  sub: string;
}

interface Milestone {
  year: string;
  event: string;
}

interface AboutContent {
  id: string;
  headline: string;
  subheadline: string;
  body_paragraph_1: string;
  body_paragraph_2: string;
  image_url: string;
  stats: Stat[];
  milestones: Milestone[];
  certifications: string[];
}

const defaultContent: AboutContent = {
  id: '',
  headline: "We don't just fix computers — we architect the technology backbone of your business.",
  subheadline: 'A decade of IT excellence across India',
  body_paragraph_1: 'ByteeVolvr Enterprises started as a small computer repair shop in Mumbai in 2013. Over a decade, we\'ve grown into a full-spectrum IT company trusted by 500+ businesses across India — from neighborhood retailers to large corporates.',
  body_paragraph_2: 'Our strength is versatility. We handle IT consulting for Fortune 500 vendors, supply genuine computer parts to resellers, provide AMC support with guaranteed SLAs, and run a growing e-commerce platform with 3,000+ technology products.',
  image_url: "https://img.rocket.new/generatedImages/rocket_gen_img_1aae0399f-1765206748858.png",
  stats: [
  { val: '10+', label: 'Years Experience', sub: 'In IT consulting & trading' },
  { val: '500+', label: 'Business Clients', sub: 'Across India' },
  { val: '3000+', label: 'Products Listed', sub: 'In our online store' },
  { val: '99.8%', label: 'AMC SLA Uptime', sub: 'Guaranteed response' }],

  milestones: [
  { year: '2013', event: 'Founded in Mumbai as an IT repair & parts shop' },
  { year: '2016', event: 'Launched B2B supply division for corporate clients' },
  { year: '2019', event: 'Expanded to full IT consulting and AMC services' },
  { year: '2022', event: 'Launched e-commerce store with pan-India delivery' },
  { year: '2025', event: 'Serving 500+ businesses with end-to-end IT solutions' }],

  certifications: ['Microsoft Partner', 'HP Authorized', 'Dell Certified', 'Lenovo Reseller', 'GST Registered']
};

export default async function AboutPage() {
  const supabase = await createClient();
  const { data } = await supabase.
  from('about_content').
  select('*').
  limit(1).
  maybeSingle();

  const content: AboutContent = data ?
  {
    ...data,
    stats: Array.isArray(data.stats) ? data.stats : defaultContent.stats,
    milestones: Array.isArray(data.milestones) ? data.milestones : defaultContent.milestones,
    certifications: Array.isArray(data.certifications) ? data.certifications : defaultContent.certifications
  } :
  defaultContent;

  return (
    <main className="min-h-screen bg-[#04080F] overflow-x-hidden">
      <Header />

      {/* Hero */}
      <section className="relative pt-40 pb-20 overflow-hidden"
      style={{ background: 'linear-gradient(180deg, #04080F 0%, #070D1A 50%, #04080F 100%)' }}>
        <div
          className="absolute inset-0 opacity-[0.03] pointer-events-none"
          style={{
            backgroundImage: 'linear-gradient(rgba(96,165,250,1) 1px, transparent 1px), linear-gradient(90deg, rgba(96,165,250,1) 1px, transparent 1px)',
            backgroundSize: '60px 60px'
          }} />
        
        <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
          <span className="text-xs font-mono text-accent uppercase tracking-widest mb-4 block">// About Us</span>
          <h1 className="font-display text-5xl lg:text-6xl font-bold text-white tracking-tight leading-tight mb-4 max-w-3xl">
            {content.headline.split('—')[0]}
            {content.headline.includes('—') &&
            <>
                <span style={{ color: 'rgba(139,155,184,0.45)' }}>
                  — {content.headline.split('—')[1]}
                </span>
              </>
            }
          </h1>
          <p className="text-brand-muted font-mono text-sm">{content.subheadline}</p>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-16 pb-32"
      style={{ background: 'linear-gradient(180deg, #070D1A 0%, #04080F 100%)' }}>
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-start">

            {/* LEFT: Story */}
            <div className="lg:col-span-7 flex flex-col gap-10">
              <div>
                <p className="text-brand-muted text-base leading-relaxed font-body mb-6">
                  {content.body_paragraph_1}
                </p>
                <p className="text-brand-muted text-base leading-relaxed font-body">
                  {content.body_paragraph_2}
                </p>
              </div>

              {/* Photo */}
              {content.image_url &&
              <div className="rounded-2xl overflow-hidden relative"
              style={{ border: '1px solid rgba(96,165,250,0.1)' }}>
                  <AppImage
                  src={content.image_url}
                  alt="ByteeVolvr technician working on computer hardware circuit board repair"
                  width={900}
                  height={400}
                  className="w-full object-cover"
                  style={{ height: '260px' }} />
                
                  <div
                  className="absolute inset-0"
                  style={{ background: 'linear-gradient(to top, rgba(4,8,15,0.7) 0%, transparent 60%)' }} />
                
                  <div className="absolute bottom-4 left-5">
                    <span className="text-xs font-mono text-accent/80">BYTEEVOLVR // MUMBAI HQ</span>
                  </div>
                </div>
              }

              {/* Milestones */}
              <div>
                <h3 className="text-xs font-mono text-brand-subtle uppercase tracking-widest mb-6">Our Journey</h3>
                <div className="flex flex-col gap-0">
                  {content.milestones?.map((m, i) =>
                  <div
                    key={m?.year}
                    className="flex items-start gap-5 py-4 border-b border-white/5 group hover:border-accent/20 transition-colors">
                    
                      <span
                      className="font-mono text-sm font-semibold shrink-0 w-12"
                      style={{ color: i === (content.milestones?.length ?? 0) - 1 ? '#60A5FA' : 'rgba(139,155,184,0.5)' }}>
                      
                        {m?.year}
                      </span>
                      <span className="text-sm text-brand-muted group-hover:text-white transition-colors font-body leading-relaxed">
                        {m?.event}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* RIGHT: Stats */}
            <div className="lg:col-span-5 flex flex-col gap-4">
              {content.stats?.map((s) =>
              <div key={s?.label} className="glass-panel card-glow rounded-2xl p-6 hover-shine group">
                  <div
                  className="text-4xl font-display font-bold mb-1"
                  style={{
                    background: 'linear-gradient(135deg, #ffffff, #60A5FA)',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                    backgroundClip: 'text'
                  }}>
                  
                    {s?.val}
                  </div>
                  <div className="text-white font-display font-semibold text-base mb-0.5">{s?.label}</div>
                  <div className="text-brand-subtle text-xs font-mono">{s?.sub}</div>
                </div>
              )}

              {/* Certifications */}
              <div className="glass-panel-blue rounded-2xl p-6 mt-2">
                <h4 className="text-xs font-mono text-accent uppercase tracking-widest mb-4">Certifications & Partners</h4>
                <div className="flex flex-wrap gap-2">
                  {content.certifications?.map((cert) =>
                  <span
                    key={cert}
                    className="text-[11px] font-mono px-3 py-1.5 rounded-full"
                    style={{ background: 'rgba(26,79,214,0.12)', border: '1px solid rgba(96,165,250,0.2)', color: '#93C5FD' }}>
                    
                      {cert}
                    </span>
                  )}
                </div>
              </div>

              {/* CTA */}
              <div className="glass-panel rounded-2xl p-6 mt-2 text-center">
                <p className="text-brand-muted text-sm font-body mb-4">Ready to work with us?</p>
                <a
                  href="/contact"
                  className="btn-primary inline-flex items-center gap-2 px-6 py-2.5 rounded-lg text-sm font-semibold text-white">
                  
                  Contact Us
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                    <line x1="5" y1="12" x2="19" y2="12" /><polyline points="12 5 19 12 12 19" />
                  </svg>
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>);

}