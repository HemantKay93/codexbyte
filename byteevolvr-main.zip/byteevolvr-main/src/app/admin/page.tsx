'use client';
import React, { useState, useEffect, useCallback } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import AppLogo from '@/components/ui/AppLogo';
import { createClient } from '@/lib/supabase/client';

type Tab = 'overview' | 'services' | 'products' | 'contacts' | 'about';

interface Service {
  id: string;
  title: string;
  description: string;
  icon_name: string;
  tags: string[];
  accent_color: string;
  sort_order: number;
  status: string;
}

interface Product {
  id: string;
  name: string;
  price: number;
  category: string;
  brand: string;
  stock_quantity: number;
  status: string;
  featured: boolean;
}

interface ContactSubmission {
  id: string;
  name: string;
  email: string;
  phone: string;
  subject: string;
  message: string;
  status: string;
  created_at: string;
}

interface Stats {
  services: number;
  products: number;
  contacts: number;
  newContacts: number;
}

export default function AdminDashboard() {
  const router = useRouter();
  const [activeTab, setActiveTab] = useState<Tab>('overview');
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState<Stats>({ services: 0, products: 0, contacts: 0, newContacts: 0 });
  const [services, setServices] = useState<Service[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [contacts, setContacts] = useState<ContactSubmission[]>([]);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [notification, setNotification] = useState('');

  // Service form state
  const [serviceForm, setServiceForm] = useState({ title: '', description: '', icon_name: 'default', tags: '', accent_color: '#3B7BF8', sort_order: 0, status: 'active' });
  const [editingService, setEditingService] = useState<string | null>(null);
  const [showServiceForm, setShowServiceForm] = useState(false);

  // Product form state
  const [productForm, setProductForm] = useState({ name: '', description: '', price: '', original_price: '', image_url: '', category: 'General', brand: '', sku: '', stock_quantity: '0', tags: '', status: 'active', featured: false });
  const [editingProduct, setEditingProduct] = useState<string | null>(null);
  const [showProductForm, setShowProductForm] = useState(false);

  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(''), 3000);
  };

  const checkAuth = useCallback(async () => {
    const supabase = createClient();
    const { data: { user: authUser } } = await supabase.auth.getUser();
    if (!authUser) {
      router.replace('/admin/login');
      return;
    }
    setUser(authUser);
    setLoading(false);
  }, [router]);

  const fetchStats = useCallback(async () => {
    const supabase = createClient();
    const [svcRes, prodRes, contactRes, newContactRes] = await Promise.all([
      supabase.from('services').select('*', { count: 'exact', head: true }),
      supabase.from('products').select('*', { count: 'exact', head: true }),
      supabase.from('contact_submissions').select('*', { count: 'exact', head: true }),
      supabase.from('contact_submissions').select('*', { count: 'exact', head: true }).eq('status', 'new'),
    ]);
    setStats({
      services: svcRes.count || 0,
      products: prodRes.count || 0,
      contacts: contactRes.count || 0,
      newContacts: newContactRes.count || 0,
    });
  }, []);

  const fetchServices = useCallback(async () => {
    const supabase = createClient();
    const { data } = await supabase.from('services').select('*').order('sort_order', { ascending: true });
    setServices(data || []);
  }, []);

  const fetchProducts = useCallback(async () => {
    const supabase = createClient();
    const { data } = await supabase.from('products').select('id, name, price, category, brand, stock_quantity, status, featured').order('sort_order', { ascending: true });
    setProducts(data || []);
  }, []);

  const fetchContacts = useCallback(async () => {
    const supabase = createClient();
    const { data } = await supabase.from('contact_submissions').select('*').order('created_at', { ascending: false });
    setContacts(data || []);
  }, []);

  useEffect(() => {
    checkAuth();
  }, [checkAuth]);

  useEffect(() => {
    if (!loading) {
      fetchStats();
      if (activeTab === 'services') fetchServices();
      if (activeTab === 'products') fetchProducts();
      if (activeTab === 'contacts') fetchContacts();
    }
  }, [loading, activeTab, fetchStats, fetchServices, fetchProducts, fetchContacts]);

  const handleSignOut = async () => {
    const supabase = createClient();
    await supabase.auth.signOut();
    router.replace('/admin/login');
  };

  // Service CRUD
  const handleSaveService = async () => {
    if (!serviceForm.title.trim()) return;
    setActionLoading('service-save');
    const supabase = createClient();
    const payload = {
      title: serviceForm.title,
      description: serviceForm.description,
      icon_name: serviceForm.icon_name,
      tags: serviceForm.tags.split(',').map((t) => t.trim()).filter(Boolean),
      accent_color: serviceForm.accent_color,
      sort_order: Number(serviceForm.sort_order),
      status: serviceForm.status,
    };
    if (editingService) {
      await supabase.from('services').update(payload).eq('id', editingService);
      showNotification('Service updated successfully');
    } else {
      await supabase.from('services').insert(payload);
      showNotification('Service created successfully');
    }
    setShowServiceForm(false);
    setEditingService(null);
    setServiceForm({ title: '', description: '', icon_name: 'default', tags: '', accent_color: '#3B7BF8', sort_order: 0, status: 'active' });
    fetchServices();
    fetchStats();
    setActionLoading(null);
  };

  const handleEditService = (svc: Service) => {
    setServiceForm({
      title: svc.title,
      description: svc.description,
      icon_name: svc.icon_name,
      tags: svc.tags?.join(', ') || '',
      accent_color: svc.accent_color,
      sort_order: svc.sort_order,
      status: svc.status,
    });
    setEditingService(svc.id);
    setShowServiceForm(true);
  };

  const handleDeleteService = async (id: string) => {
    if (!confirm('Delete this service?')) return;
    setActionLoading(`del-svc-${id}`);
    const supabase = createClient();
    await supabase.from('services').delete().eq('id', id);
    showNotification('Service deleted');
    fetchServices();
    fetchStats();
    setActionLoading(null);
  };

  // Product CRUD
  const handleSaveProduct = async () => {
    if (!productForm.name.trim()) return;
    setActionLoading('product-save');
    const supabase = createClient();
    const payload = {
      name: productForm.name,
      description: productForm.description,
      price: parseFloat(productForm.price) || 0,
      original_price: productForm.original_price ? parseFloat(productForm.original_price) : null,
      image_url: productForm.image_url,
      category: productForm.category,
      brand: productForm.brand,
      sku: productForm.sku,
      stock_quantity: parseInt(productForm.stock_quantity) || 0,
      tags: productForm.tags.split(',').map((t) => t.trim()).filter(Boolean),
      status: productForm.status,
      featured: productForm.featured,
    };
    if (editingProduct) {
      await supabase.from('products').update(payload).eq('id', editingProduct);
      showNotification('Product updated successfully');
    } else {
      await supabase.from('products').insert(payload);
      showNotification('Product created successfully');
    }
    setShowProductForm(false);
    setEditingProduct(null);
    setProductForm({ name: '', description: '', price: '', original_price: '', image_url: '', category: 'General', brand: '', sku: '', stock_quantity: '0', tags: '', status: 'active', featured: false });
    fetchProducts();
    fetchStats();
    setActionLoading(null);
  };

  const handleEditProduct = async (id: string) => {
    const supabase = createClient();
    const { data } = await supabase.from('products').select('*').eq('id', id).single();
    if (data) {
      setProductForm({
        name: data.name,
        description: data.description,
        price: String(data.price),
        original_price: data.original_price ? String(data.original_price) : '',
        image_url: data.image_url || '',
        category: data.category,
        brand: data.brand || '',
        sku: data.sku || '',
        stock_quantity: String(data.stock_quantity),
        tags: data.tags?.join(', ') || '',
        status: data.status,
        featured: data.featured,
      });
      setEditingProduct(id);
      setShowProductForm(true);
    }
  };

  const handleDeleteProduct = async (id: string) => {
    if (!confirm('Delete this product?')) return;
    setActionLoading(`del-prod-${id}`);
    const supabase = createClient();
    await supabase.from('products').delete().eq('id', id);
    showNotification('Product deleted');
    fetchProducts();
    fetchStats();
    setActionLoading(null);
  };

  const handleUpdateContactStatus = async (id: string, status: string) => {
    setActionLoading(`contact-${id}`);
    const supabase = createClient();
    await supabase.from('contact_submissions').update({ status }).eq('id', id);
    showNotification('Status updated');
    fetchContacts();
    fetchStats();
    setActionLoading(null);
  };

  const inputClass = "w-full px-3 py-2 rounded-lg text-sm font-body text-white placeholder-brand-subtle outline-none";
  const inputStyle = { background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.1)' };

  const navItems: { id: Tab; label: string; icon: React.ReactNode }[] = [
    { id: 'overview', label: 'Overview', icon: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="7" height="7" /><rect x="14" y="3" width="7" height="7" /><rect x="14" y="14" width="7" height="7" /><rect x="3" y="14" width="7" height="7" /></svg> },
    { id: 'services', label: 'Services', icon: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" /></svg> },
    { id: 'products', label: 'Products', icon: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z" /><line x1="3" y1="6" x2="21" y2="6" /></svg> },
    { id: 'contacts', label: 'Contacts', icon: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" /><polyline points="22,6 12,13 2,6" /></svg> },
  ];

  const statusColors: Record<string, { bg: string; border: string; text: string }> = {
    new: { bg: 'rgba(26,79,214,0.15)', border: 'rgba(96,165,250,0.3)', text: '#60A5FA' },
    read: { bg: 'rgba(139,155,184,0.1)', border: 'rgba(139,155,184,0.2)', text: '#8B9BB8' },
    replied: { bg: 'rgba(16,185,129,0.1)', border: 'rgba(16,185,129,0.3)', text: '#34D399' },
    archived: { bg: 'rgba(74,85,104,0.1)', border: 'rgba(74,85,104,0.3)', text: '#4A5568' },
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#04080F] flex items-center justify-center">
        <div className="text-center">
          <svg className="animate-spin mx-auto mb-4" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#60A5FA" strokeWidth="2">
            <path d="M21 12a9 9 0 11-6.219-8.56" />
          </svg>
          <p className="text-brand-muted font-mono text-sm">Loading admin panel...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#04080F] flex">
      {/* Sidebar */}
      <aside className="w-64 shrink-0 border-r border-white/5 flex flex-col"
        style={{ background: '#070D1A' }}>
        <div className="p-6 border-b border-white/5">
          <Link href="/homepage" className="flex items-center gap-2.5 mb-1">
            <AppLogo size={28} />
            <span className="font-display font-bold text-white text-sm">ByteeVolvr</span>
          </Link>
          <span className="text-[10px] font-mono text-accent uppercase tracking-widest">Admin CMS</span>
        </div>

        <nav className="flex-1 p-4 flex flex-col gap-1">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 text-left w-full"
              style={{
                background: activeTab === item.id ? 'rgba(26,79,214,0.2)' : 'transparent',
                border: activeTab === item.id ? '1px solid rgba(96,165,250,0.2)' : '1px solid transparent',
                color: activeTab === item.id ? '#60A5FA' : '#8B9BB8',
              }}
            >
              {item.icon}
              {item.label}
              {item.id === 'contacts' && stats.newContacts > 0 && (
                <span className="ml-auto text-[10px] font-mono px-1.5 py-0.5 rounded-full"
                  style={{ background: 'rgba(26,79,214,0.3)', color: '#60A5FA' }}>
                  {stats.newContacts}
                </span>
              )}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-white/5">
          <div className="mb-3 px-3">
            <p className="text-xs font-mono text-brand-subtle truncate">{user?.email}</p>
          </div>
          <div className="flex gap-2">
            <Link href="/homepage"
              className="flex-1 text-center px-3 py-2 rounded-lg text-xs font-mono text-brand-muted hover:text-white transition-colors"
              style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
              View Site
            </Link>
            <button onClick={handleSignOut}
              className="flex-1 px-3 py-2 rounded-lg text-xs font-mono text-red-400 hover:text-red-300 transition-colors"
              style={{ background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.2)' }}>
              Sign Out
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        {/* Notification */}
        {notification && (
          <div className="fixed top-4 right-4 z-50 px-4 py-3 rounded-xl text-sm font-mono text-white"
            style={{ background: 'rgba(16,185,129,0.2)', border: '1px solid rgba(16,185,129,0.4)' }}>
            ✓ {notification}
          </div>
        )}

        <div className="p-8">
          {/* Overview Tab */}
          {activeTab === 'overview' && (
            <div>
              <h1 className="font-display text-2xl font-bold text-white mb-2">Dashboard Overview</h1>
              <p className="text-brand-muted font-body text-sm mb-8">Manage your website content and track submissions.</p>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                {[
                  { label: 'Services', value: stats.services, icon: '🛡️', tab: 'services' as Tab },
                  { label: 'Products', value: stats.products, icon: '📦', tab: 'products' as Tab },
                  { label: 'Total Contacts', value: stats.contacts, icon: '📧', tab: 'contacts' as Tab },
                  { label: 'New Contacts', value: stats.newContacts, icon: '🔔', tab: 'contacts' as Tab, highlight: true },
                ].map((stat) => (
                  <button key={stat.label} onClick={() => setActiveTab(stat.tab)}
                    className="glass-panel rounded-2xl p-6 text-left hover-shine transition-all duration-200 group"
                    style={{ border: stat.highlight && stat.value > 0 ? '1px solid rgba(96,165,250,0.3)' : '1px solid rgba(255,255,255,0.06)' }}>
                    <div className="text-2xl mb-2">{stat.icon}</div>
                    <div className="font-display text-3xl font-bold text-white mb-1">{stat.value}</div>
                    <div className="text-brand-muted text-xs font-mono">{stat.label}</div>
                  </button>
                ))}
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                {[
                  { href: '/services', label: 'Services Page', desc: 'View live services page' },
                  { href: '/products', label: 'Products Page', desc: 'View live products page' },
                  { href: '/contact', label: 'Contact Page', desc: 'View live contact page' },
                  { href: '/about', label: 'About Page', desc: 'View live about page' },
                ].map((link) => (
                  <Link key={link.href} href={link.href} target="_blank"
                    className="glass-panel rounded-xl p-4 flex items-center justify-between group hover:border-accent/20 transition-all"
                    style={{ border: '1px solid rgba(255,255,255,0.06)' }}>
                    <div>
                      <p className="text-white text-sm font-semibold font-display">{link.label}</p>
                      <p className="text-brand-subtle text-xs font-mono">{link.desc}</p>
                    </div>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#60A5FA" strokeWidth="2" className="opacity-0 group-hover:opacity-100 transition-opacity">
                      <line x1="5" y1="12" x2="19" y2="12" /><polyline points="12 5 19 12 12 19" />
                    </svg>
                  </Link>
                ))}
              </div>
            </div>
          )}

          {/* Services Tab */}
          {activeTab === 'services' && (
            <div>
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h1 className="font-display text-2xl font-bold text-white mb-1">Services</h1>
                  <p className="text-brand-muted text-sm font-body">{stats.services} service{stats.services !== 1 ? 's' : ''} total</p>
                </div>
                <button
                  onClick={() => { setShowServiceForm(true); setEditingService(null); setServiceForm({ title: '', description: '', icon_name: 'default', tags: '', accent_color: '#3B7BF8', sort_order: 0, status: 'active' }); }}
                  className="btn-primary px-4 py-2 rounded-xl text-sm font-semibold text-white flex items-center gap-2"
                >
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" /></svg>
                  Add Service
                </button>
              </div>

              {showServiceForm && (
                <div className="glass-panel rounded-2xl p-6 mb-6" style={{ border: '1px solid rgba(96,165,250,0.2)' }}>
                  <h3 className="font-display text-lg font-semibold text-white mb-4">{editingService ? 'Edit Service' : 'New Service'}</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-mono text-brand-subtle mb-1">Title *</label>
                      <input className={inputClass} style={inputStyle} value={serviceForm.title} onChange={(e) => setServiceForm((p) => ({ ...p, title: e.target.value }))} placeholder="Service title" />
                    </div>
                    <div>
                      <label className="block text-xs font-mono text-brand-subtle mb-1">Icon Name</label>
                      <select className={inputClass} style={inputStyle} value={serviceForm.icon_name} onChange={(e) => setServiceForm((p) => ({ ...p, icon_name: e.target.value }))}>
                        {['monitor', 'wrench', 'shield', 'briefcase', 'users', 'shopping-bag', 'default'].map((i) => (
                          <option key={i} value={i} style={{ background: '#04080F' }}>{i}</option>
                        ))}
                      </select>
                    </div>
                    <div className="sm:col-span-2">
                      <label className="block text-xs font-mono text-brand-subtle mb-1">Description</label>
                      <textarea className={inputClass} style={inputStyle} value={serviceForm.description} onChange={(e) => setServiceForm((p) => ({ ...p, description: e.target.value }))} rows={3} placeholder="Service description" />
                    </div>
                    <div>
                      <label className="block text-xs font-mono text-brand-subtle mb-1">Tags (comma-separated)</label>
                      <input className={inputClass} style={inputStyle} value={serviceForm.tags} onChange={(e) => setServiceForm((p) => ({ ...p, tags: e.target.value }))} placeholder="Tag1, Tag2, Tag3" />
                    </div>
                    <div>
                      <label className="block text-xs font-mono text-brand-subtle mb-1">Accent Color</label>
                      <input type="color" className="w-full h-10 rounded-lg cursor-pointer" style={inputStyle} value={serviceForm.accent_color} onChange={(e) => setServiceForm((p) => ({ ...p, accent_color: e.target.value }))} />
                    </div>
                    <div>
                      <label className="block text-xs font-mono text-brand-subtle mb-1">Sort Order</label>
                      <input type="number" className={inputClass} style={inputStyle} value={serviceForm.sort_order} onChange={(e) => setServiceForm((p) => ({ ...p, sort_order: Number(e.target.value) }))} />
                    </div>
                    <div>
                      <label className="block text-xs font-mono text-brand-subtle mb-1">Status</label>
                      <select className={inputClass} style={inputStyle} value={serviceForm.status} onChange={(e) => setServiceForm((p) => ({ ...p, status: e.target.value }))}>
                        <option value="active" style={{ background: '#04080F' }}>Active</option>
                        <option value="draft" style={{ background: '#04080F' }}>Draft</option>
                      </select>
                    </div>
                  </div>
                  <div className="flex gap-3 mt-4">
                    <button onClick={handleSaveService} disabled={actionLoading === 'service-save'}
                      className="btn-primary px-5 py-2 rounded-xl text-sm font-semibold text-white disabled:opacity-60">
                      {actionLoading === 'service-save' ? 'Saving...' : (editingService ? 'Update Service' : 'Create Service')}
                    </button>
                    <button onClick={() => { setShowServiceForm(false); setEditingService(null); }}
                      className="px-5 py-2 rounded-xl text-sm font-mono text-brand-muted hover:text-white transition-colors"
                      style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
                      Cancel
                    </button>
                  </div>
                </div>
              )}

              <div className="flex flex-col gap-3">
                {services.map((svc) => (
                  <div key={svc.id} className="glass-panel rounded-xl p-4 flex items-center justify-between gap-4"
                    style={{ border: '1px solid rgba(255,255,255,0.06)' }}>
                    <div className="flex items-center gap-4 flex-1 min-w-0">
                      <div className="w-8 h-8 rounded-lg shrink-0 flex items-center justify-center"
                        style={{ background: `${svc.accent_color}20`, border: `1px solid ${svc.accent_color}40` }}>
                        <div style={{ width: 14, height: 14, background: svc.accent_color, borderRadius: '50%' }} />
                      </div>
                      <div className="min-w-0">
                        <p className="text-white text-sm font-semibold font-display truncate">{svc.title}</p>
                        <p className="text-brand-subtle text-xs font-mono">{svc.tags?.join(', ')}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <span className="text-[10px] font-mono px-2 py-1 rounded-full"
                        style={{ background: svc.status === 'active' ? 'rgba(16,185,129,0.1)' : 'rgba(139,155,184,0.1)', border: svc.status === 'active' ? '1px solid rgba(16,185,129,0.3)' : '1px solid rgba(139,155,184,0.2)', color: svc.status === 'active' ? '#34D399' : '#8B9BB8' }}>
                        {svc.status}
                      </span>
                      <button onClick={() => handleEditService(svc)} className="p-1.5 rounded-lg text-brand-muted hover:text-accent transition-colors"
                        style={{ background: 'rgba(255,255,255,0.04)' }}>
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7" /><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z" /></svg>
                      </button>
                      <button onClick={() => handleDeleteService(svc.id)} disabled={actionLoading === `del-svc-${svc.id}`}
                        className="p-1.5 rounded-lg text-brand-muted hover:text-red-400 transition-colors disabled:opacity-50"
                        style={{ background: 'rgba(255,255,255,0.04)' }}>
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3 6 5 6 21 6" /><path d="M19 6l-1 14H6L5 6" /><path d="M10 11v6M14 11v6" /><path d="M9 6V4h6v2" /></svg>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Products Tab */}
          {activeTab === 'products' && (
            <div>
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h1 className="font-display text-2xl font-bold text-white mb-1">Products</h1>
                  <p className="text-brand-muted text-sm font-body">{stats.products} product{stats.products !== 1 ? 's' : ''} total</p>
                </div>
                <button
                  onClick={() => { setShowProductForm(true); setEditingProduct(null); setProductForm({ name: '', description: '', price: '', original_price: '', image_url: '', category: 'General', brand: '', sku: '', stock_quantity: '0', tags: '', status: 'active', featured: false }); }}
                  className="btn-primary px-4 py-2 rounded-xl text-sm font-semibold text-white flex items-center gap-2"
                >
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" /></svg>
                  Add Product
                </button>
              </div>

              {showProductForm && (
                <div className="glass-panel rounded-2xl p-6 mb-6" style={{ border: '1px solid rgba(96,165,250,0.2)' }}>
                  <h3 className="font-display text-lg font-semibold text-white mb-4">{editingProduct ? 'Edit Product' : 'New Product'}</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="sm:col-span-2">
                      <label className="block text-xs font-mono text-brand-subtle mb-1">Product Name *</label>
                      <input className={inputClass} style={inputStyle} value={productForm.name} onChange={(e) => setProductForm((p) => ({ ...p, name: e.target.value }))} placeholder="Product name" />
                    </div>
                    <div className="sm:col-span-2">
                      <label className="block text-xs font-mono text-brand-subtle mb-1">Description</label>
                      <textarea className={inputClass} style={inputStyle} value={productForm.description} onChange={(e) => setProductForm((p) => ({ ...p, description: e.target.value }))} rows={2} placeholder="Product description" />
                    </div>
                    <div>
                      <label className="block text-xs font-mono text-brand-subtle mb-1">Price (₹) *</label>
                      <input type="number" className={inputClass} style={inputStyle} value={productForm.price} onChange={(e) => setProductForm((p) => ({ ...p, price: e.target.value }))} placeholder="0.00" />
                    </div>
                    <div>
                      <label className="block text-xs font-mono text-brand-subtle mb-1">Original Price (₹)</label>
                      <input type="number" className={inputClass} style={inputStyle} value={productForm.original_price} onChange={(e) => setProductForm((p) => ({ ...p, original_price: e.target.value }))} placeholder="0.00" />
                    </div>
                    <div>
                      <label className="block text-xs font-mono text-brand-subtle mb-1">Category</label>
                      <select className={inputClass} style={inputStyle} value={productForm.category} onChange={(e) => setProductForm((p) => ({ ...p, category: e.target.value }))}>
                        {['General', 'Laptops', 'Monitors', 'Peripherals', 'Printers', 'Components', 'Storage', 'Networking'].map((c) => (
                          <option key={c} value={c} style={{ background: '#04080F' }}>{c}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-mono text-brand-subtle mb-1">Brand</label>
                      <input className={inputClass} style={inputStyle} value={productForm.brand} onChange={(e) => setProductForm((p) => ({ ...p, brand: e.target.value }))} placeholder="Brand name" />
                    </div>
                    <div>
                      <label className="block text-xs font-mono text-brand-subtle mb-1">SKU</label>
                      <input className={inputClass} style={inputStyle} value={productForm.sku} onChange={(e) => setProductForm((p) => ({ ...p, sku: e.target.value }))} placeholder="SKU-001" />
                    </div>
                    <div>
                      <label className="block text-xs font-mono text-brand-subtle mb-1">Stock Quantity</label>
                      <input type="number" className={inputClass} style={inputStyle} value={productForm.stock_quantity} onChange={(e) => setProductForm((p) => ({ ...p, stock_quantity: e.target.value }))} />
                    </div>
                    <div className="sm:col-span-2">
                      <label className="block text-xs font-mono text-brand-subtle mb-1">Image URL</label>
                      <input className={inputClass} style={inputStyle} value={productForm.image_url} onChange={(e) => setProductForm((p) => ({ ...p, image_url: e.target.value }))} placeholder="https://..." />
                    </div>
                    <div>
                      <label className="block text-xs font-mono text-brand-subtle mb-1">Tags (comma-separated)</label>
                      <input className={inputClass} style={inputStyle} value={productForm.tags} onChange={(e) => setProductForm((p) => ({ ...p, tags: e.target.value }))} placeholder="tag1, tag2" />
                    </div>
                    <div>
                      <label className="block text-xs font-mono text-brand-subtle mb-1">Status</label>
                      <select className={inputClass} style={inputStyle} value={productForm.status} onChange={(e) => setProductForm((p) => ({ ...p, status: e.target.value }))}>
                        <option value="active" style={{ background: '#04080F' }}>Active</option>
                        <option value="draft" style={{ background: '#04080F' }}>Draft</option>
                        <option value="out_of_stock" style={{ background: '#04080F' }}>Out of Stock</option>
                      </select>
                    </div>
                    <div className="flex items-center gap-3">
                      <input type="checkbox" id="featured" checked={productForm.featured} onChange={(e) => setProductForm((p) => ({ ...p, featured: e.target.checked }))} className="w-4 h-4 accent-blue-500" />
                      <label htmlFor="featured" className="text-sm font-mono text-brand-muted cursor-pointer">Featured Product</label>
                    </div>
                  </div>
                  <div className="flex gap-3 mt-4">
                    <button onClick={handleSaveProduct} disabled={actionLoading === 'product-save'}
                      className="btn-primary px-5 py-2 rounded-xl text-sm font-semibold text-white disabled:opacity-60">
                      {actionLoading === 'product-save' ? 'Saving...' : (editingProduct ? 'Update Product' : 'Create Product')}
                    </button>
                    <button onClick={() => { setShowProductForm(false); setEditingProduct(null); }}
                      className="px-5 py-2 rounded-xl text-sm font-mono text-brand-muted hover:text-white transition-colors"
                      style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
                      Cancel
                    </button>
                  </div>
                </div>
              )}

              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-white/5">
                      {['Product', 'Category', 'Price', 'Stock', 'Status', 'Actions'].map((h) => (
                        <th key={h} className="text-left py-3 px-4 text-xs font-mono text-brand-subtle uppercase tracking-widest">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {products.map((prod) => (
                      <tr key={prod.id} className="border-b border-white/5 hover:bg-white/2 transition-colors">
                        <td className="py-3 px-4">
                          <div>
                            <p className="text-white text-sm font-display font-medium">{prod.name}</p>
                            <p className="text-brand-subtle text-xs font-mono">{prod.brand}</p>
                          </div>
                        </td>
                        <td className="py-3 px-4 text-brand-muted text-xs font-mono">{prod.category}</td>
                        <td className="py-3 px-4 text-white text-sm font-mono">₹{prod.price.toLocaleString('en-IN')}</td>
                        <td className="py-3 px-4 text-brand-muted text-xs font-mono">{prod.stock_quantity}</td>
                        <td className="py-3 px-4">
                          <span className="text-[10px] font-mono px-2 py-1 rounded-full"
                            style={{ background: prod.status === 'active' ? 'rgba(16,185,129,0.1)' : 'rgba(139,155,184,0.1)', border: prod.status === 'active' ? '1px solid rgba(16,185,129,0.3)' : '1px solid rgba(139,155,184,0.2)', color: prod.status === 'active' ? '#34D399' : '#8B9BB8' }}>
                            {prod.status}
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex gap-2">
                            <button onClick={() => handleEditProduct(prod.id)} className="p-1.5 rounded-lg text-brand-muted hover:text-accent transition-colors" style={{ background: 'rgba(255,255,255,0.04)' }}>
                              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7" /><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z" /></svg>
                            </button>
                            <button onClick={() => handleDeleteProduct(prod.id)} disabled={actionLoading === `del-prod-${prod.id}`} className="p-1.5 rounded-lg text-brand-muted hover:text-red-400 transition-colors disabled:opacity-50" style={{ background: 'rgba(255,255,255,0.04)' }}>
                              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3 6 5 6 21 6" /><path d="M19 6l-1 14H6L5 6" /></svg>
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Contacts Tab */}
          {activeTab === 'contacts' && (
            <div>
              <h1 className="font-display text-2xl font-bold text-white mb-2">Contact Submissions</h1>
              <p className="text-brand-muted text-sm font-body mb-6">{stats.contacts} total · {stats.newContacts} new</p>

              <div className="flex flex-col gap-4">
                {contacts.map((contact) => {
                  const sc = statusColors[contact.status] || statusColors.new;
                  return (
                    <div key={contact.id} className="glass-panel rounded-2xl p-6"
                      style={{ border: contact.status === 'new' ? '1px solid rgba(96,165,250,0.2)' : '1px solid rgba(255,255,255,0.06)' }}>
                      <div className="flex items-start justify-between gap-4 mb-4">
                        <div>
                          <div className="flex items-center gap-3 mb-1">
                            <h3 className="font-display text-base font-semibold text-white">{contact.name}</h3>
                            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full"
                              style={{ background: sc.bg, border: `1px solid ${sc.border}`, color: sc.text }}>
                              {contact.status}
                            </span>
                          </div>
                          <div className="flex flex-wrap gap-3 text-xs font-mono text-brand-subtle">
                            <span>{contact.email}</span>
                            {contact.phone && <span>{contact.phone}</span>}
                            <span>{new Date(contact.created_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
                          </div>
                        </div>
                        <select
                          value={contact.status}
                          onChange={(e) => handleUpdateContactStatus(contact.id, e.target.value)}
                          disabled={actionLoading === `contact-${contact.id}`}
                          className="text-xs font-mono px-3 py-1.5 rounded-lg outline-none disabled:opacity-60"
                          style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.1)', color: '#8B9BB8' }}
                        >
                          <option value="new" style={{ background: '#04080F' }}>New</option>
                          <option value="read" style={{ background: '#04080F' }}>Read</option>
                          <option value="replied" style={{ background: '#04080F' }}>Replied</option>
                          <option value="archived" style={{ background: '#04080F' }}>Archived</option>
                        </select>
                      </div>
                      {contact.subject && (
                        <p className="text-accent text-xs font-mono mb-2">Subject: {contact.subject}</p>
                      )}
                      <p className="text-brand-muted text-sm font-body leading-relaxed">{contact.message}</p>
                    </div>
                  );
                })}
                {contacts.length === 0 && (
                  <div className="text-center py-16">
                    <p className="text-brand-muted font-mono text-sm">No contact submissions yet.</p>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
