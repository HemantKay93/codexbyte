'use client';
import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import AppLogo from '@/components/ui/AppLogo';
import { createClient } from '@/lib/supabase/client';

export default function AdminLoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const supabase = createClient();
      const { error: authError } = await supabase.auth.signInWithPassword({ email, password });
      if (authError) {
        setError(authError.message);
      } else {
        router.push('/admin');
        router.refresh();
      }
    } catch {
      setError('An unexpected error occurred.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="min-h-screen bg-[#04080F] flex items-center justify-center px-4">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[400px] pointer-events-none"
        style={{ background: 'radial-gradient(ellipse, rgba(26,79,214,0.12) 0%, transparent 70%)' }} />

      <div className="w-full max-w-md relative z-10">
        <div className="text-center mb-8">
          <Link href="/homepage" className="inline-flex items-center gap-2.5 mb-6">
            <AppLogo size={40} />
            <span className="font-display font-bold text-xl text-white">ByteeVolvr</span>
          </Link>
          <h1 className="font-display text-2xl font-bold text-white mb-2">Admin CMS</h1>
          <p className="text-brand-muted text-sm font-body">Sign in to manage your content</p>
        </div>

        <div className="glass-panel rounded-2xl p-8">
          <form onSubmit={handleLogin} className="flex flex-col gap-5">
            <div>
              <label className="block text-xs font-mono text-brand-subtle uppercase tracking-widest mb-2">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="admin@byteevolvr.com"
                required
                className="w-full px-4 py-3 rounded-xl text-sm font-body text-white placeholder-brand-subtle outline-none"
                style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)' }}
                onFocus={(e) => { e.currentTarget.style.borderColor = 'rgba(96,165,250,0.4)'; }}
                onBlur={(e) => { e.currentTarget.style.borderColor = 'rgba(255,255,255,0.08)'; }}
              />
            </div>
            <div>
              <label className="block text-xs font-mono text-brand-subtle uppercase tracking-widest mb-2">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                className="w-full px-4 py-3 rounded-xl text-sm font-body text-white placeholder-brand-subtle outline-none"
                style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)' }}
                onFocus={(e) => { e.currentTarget.style.borderColor = 'rgba(96,165,250,0.4)'; }}
                onBlur={(e) => { e.currentTarget.style.borderColor = 'rgba(255,255,255,0.08)'; }}
              />
            </div>

            {error && <p className="text-red-400 text-sm font-mono">{error}</p>}

            <button
              type="submit"
              disabled={loading}
              className="btn-primary w-full py-3 rounded-xl text-sm font-semibold text-white flex items-center justify-center gap-2 disabled:opacity-60"
            >
              {loading ? (
                <>
                  <svg className="animate-spin" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M21 12a9 9 0 11-6.219-8.56" />
                  </svg>
                  Signing in...
                </>
              ) : 'Sign In'}
            </button>
          </form>

          <div className="mt-6 pt-6 border-t border-white/5">
            <p className="text-brand-subtle text-xs font-mono text-center mb-2">Demo credentials:</p>
            <p className="text-accent text-xs font-mono text-center">admin@byteevolvr.com / Admin@123</p>
          </div>
        </div>

        <p className="text-center mt-6">
          <Link href="/homepage" className="text-brand-subtle text-xs font-mono hover:text-accent transition-colors">
            ← Back to website
          </Link>
        </p>
      </div>
    </main>
  );
}
