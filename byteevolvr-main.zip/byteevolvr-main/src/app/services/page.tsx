import React from 'react';
import type { Metadata } from 'next';
import { createClient } from '@/lib/supabase/server';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

export const metadata: Metadata = {
  title: 'Our Services — ByteeVolvr Enterprises',
  description: 'Explore ByteeVolvr\'s full range of IT services: consulting, repair, AMC contracts, parts trading, B2B supply, and e-commerce.',
};

interface Service {
  id: string;
  title: string;
  description: string;
  icon_name: string;
  tags: string[];
  accent_color: string;
  sort_order: number;
  status: string;
}

const iconMap: Record<string, React.ReactNode> = {
  monitor: (
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <rect x="2" y="3" width="20" height="14" rx="2" /><line x1="8" y1="21" x2="16" y2="21" /><line x1="12" y1="17" x2="12" y2="21" />
    </svg>
  ),
  wrench: (
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M14.7 6.3a1 1 0 000 1.4l1.6 1.6a1 1 0 001.4 0l3.77-3.77a6 6 0 01-7.94 7.94l-6.91 6.91a2.12 2.12 0 01-3-3l6.91-6.91a6 6 0 017.94-7.94l-3.76 3.76z" />
    </svg>
  ),
  shield: (
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
    </svg>
  ),
  briefcase: (
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <rect x="2" y="7" width="20" height="14" rx="2" /><path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16" />
    </svg>
  ),
  users: (
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M23 21v-2a4 4 0 00-3-3.87" /><path d="M16 3.13a4 4 0 010 7.75" />
    </svg>
  ),
  'shopping-bag': (
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z" /><line x1="3" y1="6" x2="21" y2="6" /><path d="M16 10a4 4 0 01-8 0" />
    </svg>
  ),
  default: (
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <circle cx="12" cy="12" r="10" /><line x1="12" y1="8" x2="12" y2="16" /><line x1="8" y1="12" x2="16" y2="12" />
    </svg>
  ),
};

export default async function ServicesPage() {
  const supabase = await createClient();
  const { data: services, error } = await supabase
    .from('services')
    .select('*')
    .eq('status', 'active')
    .order('sort_order', { ascending: true });

  const serviceList: Service[] = services || [];

  return (
    <main className="min-h-screen bg-[#04080F] overflow-x-hidden">
      <Header />

      {/* Hero */}
      <section className="relative pt-40 pb-20 overflow-hidden">
        <div
          className="absolute top-0 left-1/2 -translate-x-1/2 w-[900px] h-[500px] pointer-events-none"
          style={{ background: 'radial-gradient(ellipse, rgba(26,79,214,0.12) 0%, transparent 70%)' }}
        />
        <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
          <span className="text-xs font-mono text-accent uppercase tracking-widest mb-4 block">// What We Do</span>
          <h1 className="font-display text-5xl lg:text-7xl font-bold text-white tracking-tight leading-[0.9] mb-6">
            <span className="block">Full-Stack</span>
            <span className="block" style={{ color: 'rgba(139,155,184,0.5)' }}>IT Services</span>
          </h1>
          <p className="text-brand-muted text-lg max-w-2xl font-body leading-relaxed">
            From infrastructure consulting to hands-on repair, AMC contracts to bulk B2B supply — ByteeVolvr delivers end-to-end technology solutions for businesses of every size.
          </p>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-16 pb-32">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          {error && (
            <div className="glass-panel rounded-2xl p-6 mb-8 border border-red-500/20">
              <p className="text-red-400 font-mono text-sm">Failed to load services. Please try again.</p>
            </div>
          )}

          {serviceList.length === 0 && !error ? (
            <div className="text-center py-20">
              <p className="text-brand-muted font-mono text-sm">No services available at the moment.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-px"
              style={{ background: 'rgba(255,255,255,0.04)', borderRadius: '16px', overflow: 'hidden' }}>
              {serviceList.map((svc) => (
                <div
                  key={svc.id}
                  className="group p-8 hover-shine"
                  style={{
                    background: '#04080F',
                    borderRight: '1px solid rgba(255,255,255,0.04)',
                    borderBottom: '1px solid rgba(255,255,255,0.04)',
                    transition: 'background 0.4s ease',
                  }}
                  onMouseEnter={(e) => { (e.currentTarget as HTMLDivElement).style.background = '#070D1A'; }}
                  onMouseLeave={(e) => { (e.currentTarget as HTMLDivElement).style.background = '#04080F'; }}
                >
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center mb-5 transition-all duration-300 group-hover:scale-110"
                    style={{
                      background: `${svc.accent_color}15`,
                      border: `1px solid ${svc.accent_color}30`,
                      color: svc.accent_color,
                    }}
                  >
                    {iconMap[svc.icon_name] || iconMap.default}
                  </div>
                  <h3 className="font-display text-xl font-semibold text-white mb-3 group-hover:text-accent transition-colors">
                    {svc.title}
                  </h3>
                  <p className="text-brand-muted text-sm leading-relaxed mb-5 font-body">
                    {svc.description}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {svc.tags?.map((tag) => (
                      <span
                        key={tag}
                        className="text-[10px] font-mono px-2.5 py-1 rounded-full"
                        style={{
                          background: `${svc.accent_color}10`,
                          border: `1px solid ${svc.accent_color}25`,
                          color: svc.accent_color,
                        }}
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 border-t border-white/5">
        <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center">
          <h2 className="font-display text-3xl lg:text-4xl font-bold text-white mb-4">
            Need a custom IT solution?
          </h2>
          <p className="text-brand-muted mb-8 font-body">
            Talk to our team and get a tailored proposal for your business.
          </p>
          <a
            href="/contact"
            className="btn-primary inline-flex items-center gap-2 px-8 py-3 rounded-lg text-sm font-semibold text-white"
          >
            Get in Touch
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <line x1="5" y1="12" x2="19" y2="12" /><polyline points="12 5 19 12 12 19" />
            </svg>
          </a>
        </div>
      </section>

      <Footer />
    </main>
  );
}
