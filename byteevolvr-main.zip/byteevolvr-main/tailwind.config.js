/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#1A4FD6',
          light: '#3B7BF8',
          dark: '#1240B0',
        },
        accent: {
          DEFAULT: '#60A5FA',
          glow: 'rgba(96, 165, 250, 0.3)',
        },
        brand: {
          bg: '#04080F',
          bg2: '#070D1A',
          bg3: '#0A1628',
          surface: 'rgba(255, 255, 255, 0.03)',
          border: 'rgba(255, 255, 255, 0.07)',
          fg: '#E8EDF5',
          muted: '#8B9BB8',
          subtle: '#4A5568',
        },
      },
      fontFamily: {
        display: ['Manrope', 'sans-serif'],
        body: ['DM Sans', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
      animation: {
        'light-scan': 'light-scan 6s linear infinite',
        'beam-flow': 'beam-flow 3s linear infinite',
        'float': 'float-gentle 4s ease-in-out infinite',
        'blob': 'blob-morph 12s ease-in-out infinite',
        'gradient': 'gradient-shift 8s ease infinite',
        'scan': 'sys-scan 10s linear infinite',
        'pulse-glow': 'pulse-glow 2s ease-in-out infinite',
        'fade-up': 'fade-up 0.8s cubic-bezier(0.16,1,0.3,1) forwards',
        'scale-in': 'scale-in 0.6s cubic-bezier(0.16,1,0.3,1) forwards',
      },
      keyframes: {
        'light-scan': {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '300% 0' },
        },
        'beam-flow': {
          from: { strokeDashoffset: '1200' },
          to: { strokeDashoffset: '-200' },
        },
        'float-gentle': {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-8px)' },
        },
        'blob-morph': {
          '0%, 100%': { borderRadius: '60% 40% 30% 70% / 60% 30% 70% 40%', transform: 'translate(0,0) scale(1)' },
          '25%': { borderRadius: '30% 60% 70% 40% / 50% 60% 30% 60%', transform: 'translate(20px,-20px) scale(1.05)' },
          '50%': { borderRadius: '50% 50% 30% 70% / 40% 60% 60% 40%', transform: 'translate(-10px,10px) scale(0.95)' },
          '75%': { borderRadius: '70% 30% 50% 50% / 60% 40% 50% 50%', transform: 'translate(10px,20px) scale(1.02)' },
        },
        'gradient-shift': {
          '0%': { backgroundPosition: '0% 50%' },
          '50%': { backgroundPosition: '100% 50%' },
          '100%': { backgroundPosition: '0% 50%' },
        },
        'sys-scan': {
          '0%': { top: '-10%', opacity: '0' },
          '10%': { opacity: '1' },
          '90%': { opacity: '1' },
          '100%': { top: '110%', opacity: '0' },
        },
        'pulse-glow': {
          '0%, 100%': { opacity: '0.4', transform: 'scale(1)' },
          '50%': { opacity: '1', transform: 'scale(1.15)' },
        },
        'fade-up': {
          from: { transform: 'translateY(30px)', opacity: '0' },
          to: { transform: 'translateY(0)', opacity: '1' },
        },
        'scale-in': {
          from: { transform: 'scale(0.92)', opacity: '0' },
          to: { transform: 'scale(1)', opacity: '1' },
        },
      },
      backgroundSize: {
        '300%': '300% 300%',
      },
    },
  },
  plugins: [],
};